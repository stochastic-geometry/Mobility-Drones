function B = RWP_PDF_Approx(ux, t, u0, MaxN, v, sigmaRayleigh, muExpTime, aMat, MaxIter)
nIntPDF = zeros(MaxN, 1);
fR1 = @(r1) raylpdf(r1, sigmaRayleigh);%@(r1) exppdf(r1, muExp);%
FR1 = @(r1) raylcdf(r1, sigmaRayleigh);%@(r1) expcdf(r1, muExp);%
fW1 = @(t) gampdf(t, 2, muExpTime);
FW1 = @(t) gamcdf(t, 2, muExpTime);
fW0 = @(t) exppdf(t, muExpTime);
FW0 = @(t) expcdf(t, muExpTime);
nIntPDF(1) = integral(@(x) fW0(t - x / v) .* (1 - FR1(x)) / v .* 1 / pi .* acos((x .^ 2 + ux ^ 2 - u0 ^ 2) ./ (2 * ux * x)), abs(ux - u0), min(v * t, ux + u0));
nIntPDF(2) = integral(@(x) fR1(x) .* (FW0(t - x / v) - FW1(t - x / v)) .* 1 / pi .* acos((x .^ 2 + ux ^ 2 - u0 ^ 2) ./ (2 * ux * x)), abs(ux - u0), min(v * t, ux + u0)) + ...
    integral3(@(x, w1, r1) 2 * x / pi .* (1 - FR1(v * t - v * w1 - r1)) .* fR1(r1) .* fW1(w1) ./ sqrt(((v * t - v * w1) .^ 2 - x .^ 2) .* (x .^ 2 - (2 * r1 - (v * t - v * w1)) .^ 2)) * 1 / pi .* acos((x .^ 2 + ux ^ 2 - u0 ^ 2) ./ (2 * ux * x)), ...
    abs(ux - u0), min(v * t, ux + u0), 0, @(x) t - x / v, @(x, w1) ((v * t - v * w1) - x) / 2, @(x, w1) ((v * t - v * w1) + x) / 2);
for n = 3 : MaxN
    m = n - 1;
    sigmaRayleighN = sqrt(m * sigmaRayleigh ^ 2);%sqrt((n - 1) / 2 * (sigma2Exp + muExpTime ^ 2));%
    fZ = @(r) raylpdf(r, sigmaRayleighN);
    % FZ = @(r) raylcdf(r, sigmaRayleighN);
    % fRn = @(rn) raylpdf(rn, sigmaRayleigh);%@(rn) exppdf(rn, muExp);%
    FRn = @(rn) raylcdf(rn, sigmaRayleigh);%@(rn) expcdf(rn, muExp);%
    fWn1 = @(tn) gampdf(tn, n, muExpTime);
    FWn1 = @(tn) gamcdf(tn, n, muExpTime);
    FWn2 = @(tn) gamcdf(tn, n - 1, muExpTime);
    if n == 3
        fS = @(s) s / (2 * sigmaRayleigh ^ 2) .* exp(-s .^ 2 / (2 * sigmaRayleigh ^ 2)) + sqrt(pi) / 4 * (s .^ 2 - 2 * sigmaRayleigh ^ 2) / (sigmaRayleigh ^ 3) .* exp(-s .^ 2 / (4 * sigmaRayleigh ^ 2)) .* erf(s / (2 * sigmaRayleigh));
    else
        b = sigmaRayleigh ^ 2 / (2 * m) * (factorial(2 * m) / factorial(m)) ^ (1 / m);
        a0 = aMat(m, 1);
        a1 = aMat(m, 2);
        a2 = aMat(m, 3);
        fS = @(s) (((s / sqrt(m)) .^ (2 * m - 1) .* exp(-(s / sqrt(m)) .^ 2 / (2 * b)) / (2 ^ (m - 1) * b ^ m * factorial(m - 1))) - (((s / sqrt(m)) - a2) .^ (2 * m - 2) .* exp(-a1 * ((s / sqrt(m)) - a2) .^ 2 / (2 * b)) / (2 ^ (m - 1) * b * (b / a1) ^ m * factorial(m - 1)) * a0 .* (b * (2 * m * (s / sqrt(m))  - a2) - a1 * (s / sqrt(m)) .* ((s / sqrt(m)) - a2) .^ 2))) / sqrt(m);
    end
    % fS = @(s) sqrt(n - 1) * (s / sqrt(n - 1)) .^ (2 * n - 3) .* exp(-(s / sqrt(n - 1)) .^ 2 / (2 * b)) / (2 ^ (n - 2) * b ^ (n - 1) * factorial(n - 2));
    % fS = @(s) gampdf(s, n - 1, muExpTime);
    xMax1 = min(v * t, ux + u0) - abs(ux - u0);
    yMax1 = (v * t + min(v * t, ux + u0)) / 2;
    zMax1 = (v * t + min(v * t, ux + u0)) / 2;
    wMax1 = t;
    fun1 = 0;
    tic
    parfor k = 1 : MaxIter
        x1 = rand * xMax1 + abs(ux - u0);
        y1 = rand * yMax1 + (v * t - min(v * t, ux + u0)) / 2;
        z1 = rand * zMax1;
        w1 = rand * wMax1;
        if (w1 < y1 / v) && (z1 > abs(x1 - (v * t - y1))) && (z1 < min(y1, x1 + (v * t - y1))) && (y1 > (v * t - x1) / 2)
            fun1 = fun1 + fWn1(w1) * fS(y1 - v * w1) * fZ(z1) * 2 * x1 / pi * (1 - FRn(v * t - y1)) / sqrt((x1 ^ 2 - (z1 - (v * t - y1)) ^ 2) * ((z1 + (v * t - y1)) ^ 2 - x1 ^ 2)) * 1 / pi * acos((x1 ^ 2 + ux ^ 2 - u0 ^ 2) / (2 * ux * x1));
        end
    end
    toc
    q1 = xMax1 * yMax1 * zMax1 * wMax1 * fun1 / MaxIter;
    q0 = integral2(@(x, s) fS(s) .* fZ(x) .* (FWn2(t - s / v) - FWn1(t - s / v)) .* 1 / pi .* acos((x .^ 2 + ux ^ 2 - u0 ^ 2) ./ (2 * ux * x)), abs(ux - u0), min(v * t, ux + u0), @(x) x, v * t);
    nIntPDF(n) = q0 + q1;
end
B = sum(nIntPDF);