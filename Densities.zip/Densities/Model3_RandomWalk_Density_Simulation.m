%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%                                                                     %%%
%%%   Paper: Performance Characterization of Canonical Mobility Models  %%%
%%%          in Drone Cellular Networks                                 %%%
%%%   Authors: Morteza Banagar, Harpreet S. Dhillon                     %%%
%%%   Emails: mbanagar@vt.edu, hdhillon@vt.edu                          %%%
%%%                                                                     %%%
%%%   This code is used to generate the simulation data for Fig. 6,     %%%
%%%   density of the network of interferers in the random walk          %%%
%%%   mobility model                                                    %%%
%%%                                                                     %%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

datetime('now')
lambda0UAV = 1e-6;
R_UAV = 1e4;
NumUAV_Initial = lambda0UAV * pi * R_UAV ^ 2;
v = 45; % [km/h]
v = v / 3.6; % [m/s]
dr = 1;%10;%
NumR = round((R_UAV - dr) / dr) + 1;
sigmaRayleigh = 500 * sqrt(2 / pi);%muExp = 500;%
u0 = 500;
tVec = [20, 40, 50, 200]; % Condition: v * t < R_UAV
tLen = length(tVec);
CountPointsAll = zeros(tLen, NumR);
Realizations = 1e8;
tic
ierr = 0;
parfor i = 1 : Realizations
    CountPoints = zeros(tLen, NumR);
    NumUAV = poissrnd(NumUAV_Initial);
    PosUAV_Range = unifrnd(0, 1, NumUAV, 1);
    PosUAV_Range = R_UAV * sqrt(PosUAV_Range);
    PosUAV_Theta = unifrnd(0, 2 * pi, NumUAV, 1);
    f = PosUAV_Range <= u0;
    PosUAV_Range(f) = [];
    PosUAV_Theta(f) = [];
    NumUAV = length(PosUAV_Range);
    PosUAV = repmat(PosUAV_Range, 1, 2) .* [cos(PosUAV_Theta), sin(PosUAV_Theta)];
    kk = 0;
    for t = tVec
        kk = kk + 1;
        if t <= 50
            MaxN = 10;
        elseif t <= 100
            MaxN = 15;
        elseif t <= 300
            MaxN = 20;
        else
            MaxN = 30;
        end
        MovementDistVec = raylrnd(sigmaRayleigh, [NumUAV, MaxN]);%exprnd(mu, [NumUAV, MaxN]);%
        MovementThetaVec = unifrnd(0, 2 * pi, [NumUAV, MaxN]);
        S = [zeros(NumUAV, 1), cumsum(MovementDistVec, 2)];
        RC = [zeros(NumUAV, 1), cumsum(MovementDistVec .* cos(MovementThetaVec), 2)];
        RS = [zeros(NumUAV, 1), cumsum(MovementDistVec .* sin(MovementThetaVec), 2)];
        RangeVec = zeros(NumUAV, 1);
        %{}
        n = MaxN + 1 - sum((v * t - S) < 0, 2);
        for j = 1 : NumUAV
            if n(j) > MaxN % In case MaxN is not large enough
                ierr = ierr + 1;
                RangeVec(j) = max(1, sum(RangeVec(1 : j - 1)) / j);
                continue;
            end
            vd = (v * t - S(j, n(j))) * [cos(MovementThetaVec(j, n(j))), sin(MovementThetaVec(j, n(j)))];
            DisplacedPosUAV = [PosUAV(j, 1) + RC(j, n(j)) + vd(1), PosUAV(j, 2) + RS(j, n(j)) + vd(2)];
            RangeVec(j) = sqrt(DisplacedPosUAV(1) ^ 2 + DisplacedPosUAV(2) ^ 2);
        end
        %}
        %{
        for j = 1 : NumUAV
            for n = 1 : MaxN
                S1 = S(j, n);
                S2 = S(j, n + 1);
                if (v * t >= S1) && (v * t < S2)
                    vd = (v * t - S1) * [cos(MovementThetaVec(j, n)), sin(MovementThetaVec(j, n))];
                    DisplacedPosUAV = [PosUAV(j, 1) + RC(j, n) + vd(1), PosUAV(j, 2) + RS(j, n) + vd(2)];
                    RangeVec(j) = sqrt(DisplacedPosUAV(1) ^ 2 + DisplacedPosUAV(2) ^ 2);
                    break;
                end
                if n == MaxN % In case MaxN is not large enough
                    RangeVec(j) = max(1, sum(RangeVec(1 : j - 1)) / j);
                end
            end
        end
        %}
        SlottedRange = ceil(RangeVec / dr);
        [a, b] = hist(SlottedRange, unique(SlottedRange));
        CountPoints(kk, b) = a;
    end
    CountPoints = CountPoints(:, 1 : NumR);
    CountPointsAll = CountPointsAll + CountPoints;
end
toc
AreaAnnulus = pi * (2 * (0 : dr : R_UAV - dr) * dr + dr ^ 2);
CountPointsAll = CountPointsAll / Realizations;
Density_Simulation = CountPointsAll ./ repmat(AreaAnnulus, tLen, 1);
save('Model3_RandomWalk_Density_Simulation', 'Density_Simulation')
datetime('now')