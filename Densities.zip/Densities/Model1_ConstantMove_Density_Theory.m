%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%                                                                     %%%
%%%   Paper: Performance Characterization of Canonical Mobility Models  %%%
%%%          in Drone Cellular Networks                                 %%%
%%%   Authors: Morteza Banagar, Harpreet S. Dhillon                     %%%
%%%   Emails: mbanagar@vt.edu, hdhillon@vt.edu                          %%%
%%%                                                                     %%%
%%%   This code is used to generate the theoretical data for Fig. 5,    %%%
%%%   density of the network of interferers in the straight-line        %%%
%%%   mobility model                                                    %%%
%%%                                                                     %%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

datetime('now')
lambda0UAV = 1e-6;
R_UAV = 1e4;
NumUAV_Initial = lambda0UAV * pi * R_UAV ^ 2;
v = 45; % [km/h]
v = v / 3.6; % [m/s]
dr = 1;%10;%
NumR = round((R_UAV - dr) / dr) + 1;
u0 = 500;
tVec = [20, 40, 50, 200]; % Condition: v * t < R_UAV
tLen = length(tVec);
Density_Theory = zeros(tLen, NumR);
kk = 0;
for t = tVec
    kk = kk + 1;
    if u0 < v * t
        for ux = dr : dr : round(abs(u0 - v * t))
            Density_Theory(kk, round(ux / dr)) = lambda0UAV;
        end
    end
    for ux = round(abs(u0 - v * t) + dr) : dr : round(u0 + v * t - dr)
        A = 1 / pi * acos((u0 ^ 2 - v ^ 2 * t ^ 2 - ux ^ 2) / (2 * v * t * ux));
        Density_Theory(kk, round(ux / dr)) = lambda0UAV * A;
    end
    for ux = round(u0 + v * t) : dr : round(R_UAV)
        Density_Theory(kk, round(ux / dr)) = lambda0UAV;
    end
end
save('Model1_ConstantMove_Density_Theory', 'Density_Theory')
datetime('now')