%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%                                                                     %%%
%%%   Paper: Performance Characterization of Canonical Mobility Models  %%%
%%%          in Drone Cellular Networks                                 %%%
%%%   Authors: Morteza Banagar, Harpreet S. Dhillon                     %%%
%%%   Emails: mbanagar@vt.edu, hdhillon@vt.edu                          %%%
%%%                                                                     %%%
%%%   This code is used to generate the theoretical data for Fig. 5,    %%%
%%%   density of the network of interferers in the random stop          %%%
%%%   mobility model                                                    %%%
%%%                                                                     %%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

datetime('now')
lambda0UAV = 1e-6;
R_UAV = 1e4;
NumUAV_Initial = lambda0UAV * pi * R_UAV ^ 2;
v = 45; % [km/h]
v = v / 3.6; % [m/s]
dr = 1;%10;%
NumR = round((R_UAV - dr) / dr) + 1;
sigmaRayleigh = 500 * sqrt(2 / pi);%muExp = 500;%
u0 = 500;
tVec = [20, 40, 50, 200]; % Condition: v * t < R_UAV
tLen = length(tVec);
fR1 = @(r1) raylpdf(r1, sigmaRayleigh);%@(r1) exppdf(r1, muExp);%
FR1 = @(r1) raylcdf(r1, sigmaRayleigh);%@(r1) expcdf(r1, muExp);%
%{}
Density_Theory = zeros(tLen, NumR);
kk = 0;
for t = tVec
    kk = kk + 1;
    if u0 < v * t
        for ux = dr : dr : round(abs(u0 - v * t))
            fun1 = @(x, u0, ux) fR1(x) .* 1 / pi .* acos((u0 ^ 2 - x .^ 2 - ux ^ 2) ./ (2 * x * ux));
            A = (1 - FR1(min(v * t, u0 + ux))) * 1 / pi * acos((u0 ^ 2 - min(v * t, u0 + ux) ^ 2 - ux ^ 2) / (2 * min(v * t, u0 + ux) * ux)) + FR1(ux - u0);
            B = integral(@(x) fun1(x, u0, ux), abs(ux - u0), min(v * t, u0 + ux));
            Density_Theory(kk, round(ux / dr)) = lambda0UAV * (A + B);
        end
    end
    for ux = round(abs(u0 - v * t) + dr) : dr : round(u0 + v * t - dr)
        fun1 = @(x, u0, ux) fR1(x) .* 1 / pi .* acos((u0 ^ 2 - x .^ 2 - ux ^ 2) ./ (2 * x * ux));
        A = (1 - FR1(min(v * t, u0 + ux))) * 1 / pi * acos((u0 ^ 2 - min(v * t, u0 + ux) ^ 2 - ux ^ 2) / (2 * min(v * t, u0 + ux) * ux)) + FR1(ux - u0);
        B = integral(@(x) fun1(x, u0, ux), abs(ux - u0), min(v * t, u0 + ux));
        Density_Theory(kk, round(ux / dr)) = lambda0UAV * (A + B);
    end
    for ux = round(u0 + v * t) : dr : round(R_UAV)
        Density_Theory(kk, round(ux / dr)) = lambda0UAV;
    end
end
save('Model2_RandomStop_Density_Theory', 'Density_Theory')
c = 750;
Density_Theory_Constant = zeros(tLen, NumR);
kk = 0;
for t = tVec
    kk = kk + 1;
    if u0 < v * t
        for ux = dr : dr : round(abs(u0 - v * t))
            m = min([c, v * t, u0 + ux]);
            if c >= abs(ux - u0)
                Density_Theory_Constant(kk, round(ux / dr)) = lambda0UAV * 1 / pi * acos((u0 ^ 2 - m ^ 2 - ux ^ 2) / (2 * m * ux));
            elseif c < ux - u0
                Density_Theory_Constant(kk, round(ux / dr)) = lambda0UAV;
            end
        end
    end
    for ux = round(abs(u0 - v * t) + dr) : dr : round(u0 + v * t - dr)
        m = min([c, v * t, u0 + ux]);
        if c >= abs(ux - u0)
            Density_Theory_Constant(kk, round(ux / dr)) = lambda0UAV * 1 / pi * acos((u0 ^ 2 - m ^ 2 - ux ^ 2) / (2 * m * ux));
        elseif c < ux - u0
            Density_Theory_Constant(kk, round(ux / dr)) = lambda0UAV;
        end
    end
    for ux = round(u0 + v * t) : dr : round(R_UAV)
        Density_Theory_Constant(kk, round(ux / dr)) = lambda0UAV;
    end
end
save('Model2_RandomStop_Density_Theory_Constant', 'Density_Theory_Constant')
%}
%{
Density_Theory = zeros(tLen, NumR);
kk = 0;
for t = tVec
    kk = kk + 1;
    for ux = dr : dr : round(min(u0, abs(u0 - v * t)))
        if u0 < v * t
            fun1 = @(x, u0, ux) fR1(x) .* 1 / pi .* acos((u0 ^ 2 - x .^ 2 - ux ^ 2) ./ (2 * x * ux));
            A = (1 - FR1(min(v * t, u0 + ux))) * 1 / pi * acos((u0 ^ 2 - min(v * t, u0 + ux) ^ 2 - ux ^ 2) / (2 * min(v * t, u0 + ux) * ux)) + FR1(ux - u0);
            B = integral(@(x) fun1(x, u0, ux), abs(ux - u0), min(v * t, u0 + ux));
            Density_Theory(kk, round(ux / dr)) = lambda0UAV * (A + B);
        end
    end
    for ux = round(min(u0, abs(u0 - v * t)) + dr) : dr : round(u0 + v * t - dr)
        fun1 = @(x, u0, ux) fR1(x) .* 1 / pi .* acos((u0 ^ 2 - x .^ 2 - ux ^ 2) ./ (2 * x * ux));
        A = (1 - FR1(min(v * t, u0 + ux))) * 1 / pi * acos((u0 ^ 2 - min(v * t, u0 + ux) ^ 2 - ux ^ 2) / (2 * min(v * t, u0 + ux) * ux)) + FR1(ux - u0);
        B = integral(@(x) fun1(x, u0, ux), abs(ux - u0), min(v * t, u0 + ux));
        Density_Theory(kk, round(ux / dr)) = lambda0UAV * (A + B);
    end
    for ux = round(u0 + v * t) : dr : round(R_UAV)
        Density_Theory(kk, round(ux / dr)) = lambda0UAV;
    end
end
c = 750;
Density_Theory_C = zeros(tLen, NumR);
kk = 0;
for t = tVec
    kk = kk + 1;
    for ux = dr : dr : round(min(u0, abs(u0 - v * t)))
        if u0 < v * t
            Density_Theory_C(kk, round(ux / dr)) = lambda0UAV * 1 / pi * acos((u0 ^ 2 - min([v * t, u0 + ux, c]) ^ 2 - ux ^ 2) / (2 * min([v * t, u0 + ux, c]) * ux));
        end
    end
    for ux = round(min(u0, abs(u0 - v * t)) + dr) : dr : round(u0 + min(c, v * t) - dr)
        Density_Theory_C(kk, round(ux / dr)) = lambda0UAV * 1 / pi * acos((u0 ^ 2 - min([v * t, u0 + ux, c]) ^ 2 - ux ^ 2) / (2 * min([v * t, u0 + ux, c]) * ux));
    end
    for ux = round(u0 + min(c, v * t)) : dr : round(R_UAV)
        Density_Theory_C(kk, round(ux / dr)) = lambda0UAV;
    end
end
%}
datetime('now')