function A = RW_CDF_Approx(x, t, MaxN, v, sigmaRayleigh, aMat)
if x <= 0
    A = 0;
    return;
elseif x >= v * t
    A = 1;
    return;
end
nCDF = zeros(MaxN, 1);
fR1 = @(r1) raylpdf(r1, sigmaRayleigh);%@(r1) exppdf(r1, muExp);%
FR1 = @(r1) raylcdf(r1, sigmaRayleigh);%@(r1) expcdf(r1, muExp);%
nCDF(1) = 0;
nCDF(2) = integral(@(r1) 1 / pi * (1 - FR1(v * t - r1)) .* fR1(r1) .* acos((r1 .^ 2 + (v * t - r1) .^ 2 - x ^ 2) ./ (2 * r1 .* (v * t - r1))), (v * t - x) / 2, (v * t + x) / 2);
for n = 3 : MaxN
    tic
    m = n - 1;
    sigmaRayleighN = sqrt(m * sigmaRayleigh ^ 2);%sqrt((n - 1) / 2 * (sigma2Exp + muExp ^ 2));%
    fZ = @(r) raylpdf(r, sigmaRayleighN);
    FZ = @(r) raylcdf(r, sigmaRayleighN);
    fRn = @(rn) raylpdf(rn, sigmaRayleigh);%@(rn) exppdf(rn, muExp);%
    FRn = @(rn) raylcdf(rn, sigmaRayleigh);%@(rn) expcdf(rn, muExp);%
    if n == 3
        fS = @(s) s / (2 * sigmaRayleigh ^ 2) .* exp(-s .^ 2 / (2 * sigmaRayleigh ^ 2)) + sqrt(pi) / 4 * (s .^ 2 - 2 * sigmaRayleigh ^ 2) / (sigmaRayleigh ^ 3) .* exp(-s .^ 2 / (4 * sigmaRayleigh ^ 2)) .* erf(s / (2 * sigmaRayleigh));
    else
        b = sigmaRayleigh ^ 2 / (2 * m) * (factorial(2 * m) / factorial(m)) ^ (1 / m);
        a0 = aMat(m, 1);
        a1 = aMat(m, 2);
        a2 = aMat(m, 3);
        fS = @(s) (((s / sqrt(m)) .^ (2 * m - 1) .* exp(-(s / sqrt(m)) .^ 2 / (2 * b)) / (2 ^ (m - 1) * b ^ m * factorial(m - 1))) - (((s / sqrt(m)) - a2) .^ (2 * m - 2) .* exp(-a1 * ((s / sqrt(m)) - a2) .^ 2 / (2 * b)) / (2 ^ (m - 1) * b * (b / a1) ^ m * factorial(m - 1)) * a0 .* (b * (2 * m * (s / sqrt(m))  - a2) - a1 * (s / sqrt(m)) .* ((s / sqrt(m)) - a2) .^ 2))) / sqrt(m);
    end
    % fS = @(s) sqrt(n - 1) * (s / sqrt(n - 1)) .^ (2 * n - 3) .* exp(-(s / sqrt(n - 1)) .^ 2 / (2 * b)) / (2 ^ (n - 2) * b ^ (n - 1) * factorial(n - 2));
    % fS = @(s) gampdf(s, n - 1, muExp);
    %{}
    if n == 3
        q1fun = @(s, z, t1) (2 * z ./ (pi * sqrt(s .^ 2 - z .^ 2))) .* fRn(t1) .* fRn(s - t1) ./ sqrt(z .^ 2 - (2 * t1 - s) .^ 2) .* (1 - FRn(v * t - s));
        q1 = integral3(q1fun, v * t - x, v * t, 0, @(s) max(0, x - (v * t - s)), @(s, z) (s - z) / 2, @(s, z) (s + z) / 2);
        q2fun = @(s, z, t1) (2 * z ./ (pi * sqrt(s .^ 2 - z .^ 2))) .* fRn(t1) .* fRn(s - t1) ./ sqrt(z .^ 2 - (2 * t1 - s) .^ 2) .* (1 - FRn(v * t - s)) * 1 / pi .* acos((z .^ 2 + (v * t - s) .^ 2 - x ^ 2) ./ (2 * z .* (v * t - s)));
        q2 = integral3(q2fun, (v * t - x) / 2, v * t, @(s) abs(x - (v * t - s)), @(s) min(s, x + (v * t - s)), @(s, z) (s - z) / 2, @(s, z) (s + z) / 2);
        nCDF(n) = q1 + q2;
    else
        q1fun = @(s) FZ(x - (v * t - s)) .* (1 - FRn(v * t - s)) .* fS(s);
        q1 = integral(q1fun, v * t - x, v * t);
        q2fun = @(s, r) 1 / pi * acos((r .^ 2 + (v * t - s) .^ 2 - x ^ 2) ./ (2 * r .* (v * t - s))) .* fZ(r) .* (1 - FRn(v * t - s)) .* fS(s);
        q2 = integral2(q2fun, (v * t - x) / 2, v * t, @(s) abs(x - (v * t - s)), @(s) min(s, x + (v * t - s)));
        nCDF(n) = q1 + q2;
    end
    %}
    %{
    q1fun = @(s) FZ(x - (v * t - s)) .* (1 - FRn(v * t - s)) .* fS(s);
    q1 = integral(q1fun, v * t - x, v * t);
    q2fun = @(s, r) 1 / pi * acos((r .^ 2 + (v * t - s) .^ 2 - x ^ 2) ./ (2 * r .* (v * t - s))) .* fZ(r) .* (1 - FRn(v * t - s)) .* fS(s);
    q2 = integral2(q2fun, (v * t - x) / 2, v * t, @(s) abs(x - (v * t - s)), @(s) min(s, x + (v * t - s)));
    nCDF(n) = q1 + q2;
    %}
    toc
end
A = sum(nCDF);