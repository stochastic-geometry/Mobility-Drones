These codes generate Figs. 5 and 6 of [1].
You can run "PlotData_Densities.m" to get the plots instantly, or you can run the other files to generate the data for each figure separately.

Please cite [1] if you reuse any part of these codes.

[1] M. Banagar and H. S. Dhillon, “Performance characterization of canonical mobility models in drone cellular networks”, available online: https://arxiv.org/abs/1908.05243