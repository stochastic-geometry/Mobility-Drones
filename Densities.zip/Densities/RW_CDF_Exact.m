function A = RW_CDF_Exact(x, t, MaxN, v, sigmaRayleigh, aMat, MaxIter)
if x <= 0
    A = 0;
    return;
elseif x >= v * t
    A = 1;
    return;
end
MeanFlight = sigmaRayleigh * sqrt(pi / 2);
MeanN = v * t / MeanFlight;
nVec = max(floor(MeanN) - 2, 3) : max(ceil(MeanN) + 2, 3);
nCDF = zeros(MaxN, 1);
fR1 = @(r1) raylpdf(r1, sigmaRayleigh);%@(r1) exppdf(r1, muExp);%
FR1 = @(r1) raylcdf(r1, sigmaRayleigh);%@(r1) expcdf(r1, muExp);%
nCDF(1) = 0;
nCDF(2) = integral(@(r1) 1 / pi * (1 - FR1(v * t - r1)) .* fR1(r1) .* acos((r1 .^ 2 + (v * t - r1) .^ 2 - x ^ 2) ./ (2 * r1 .* (v * t - r1))), (v * t - x) / 2, (v * t + x) / 2);
for n = 3 : MaxN
    m = n - 1;
    sigmaRayleighN = sqrt(m * sigmaRayleigh ^ 2);%sqrt((n - 1) / 2 * (sigma2Exp + muExp ^ 2));%
    fZ = @(r) raylpdf(r, sigmaRayleighN);
    FZ = @(r) raylcdf(r, sigmaRayleighN);
    fRn = @(rn) raylpdf(rn, sigmaRayleigh);%@(rn) exppdf(rn, muExp);%
    FRn = @(rn) raylcdf(rn, sigmaRayleigh);%@(rn) expcdf(rn, muExp);%
    if n == 3
        fS = @(s) s / (2 * sigmaRayleigh ^ 2) .* exp(-s .^ 2 / (2 * sigmaRayleigh ^ 2)) + sqrt(pi) / 4 * (s .^ 2 - 2 * sigmaRayleigh ^ 2) / (sigmaRayleigh ^ 3) .* exp(-s .^ 2 / (4 * sigmaRayleigh ^ 2)) .* erf(s / (2 * sigmaRayleigh));
    else
        b = sigmaRayleigh ^ 2 / (2 * m) * (factorial(2 * m) / factorial(m)) ^ (1 / m);
        a0 = aMat(m, 1);
        a1 = aMat(m, 2);
        a2 = aMat(m, 3);
        fS = @(s) (((s / sqrt(m)) .^ (2 * m - 1) .* exp(-(s / sqrt(m)) .^ 2 / (2 * b)) / (2 ^ (m - 1) * b ^ m * factorial(m - 1))) - (((s / sqrt(m)) - a2) .^ (2 * m - 2) .* exp(-a1 * ((s / sqrt(m)) - a2) .^ 2 / (2 * b)) / (2 ^ (m - 1) * b * (b / a1) ^ m * factorial(m - 1)) * a0 .* (b * (2 * m * (s / sqrt(m))  - a2) - a1 * (s / sqrt(m)) .* ((s / sqrt(m)) - a2) .^ 2))) / sqrt(m);
    end
    % fS = @(s) sqrt(n - 1) * (s / sqrt(n - 1)) .^ (2 * n - 3) .* exp(-(s / sqrt(n - 1)) .^ 2 / (2 * b)) / (2 ^ (n - 2) * b ^ (n - 1) * factorial(n - 2));
    % fS = @(s) gampdf(s, n - 1, muExp);
    if n == 3
        q1fun = @(s, z, t1) (2 * z ./ (pi * sqrt(s .^ 2 - z .^ 2))) .* fRn(t1) .* fRn(s - t1) ./ sqrt(z .^ 2 - (2 * t1 - s) .^ 2) .* (1 - FRn(v * t - s));
        q1 = integral3(q1fun, v * t - x, v * t, 0, @(s) max(0, x - (v * t - s)), @(s, z) (s - z) / 2, @(s, z) (s + z) / 2);
        q2fun = @(s, z, t1) (2 * z ./ (pi * sqrt(s .^ 2 - z .^ 2))) .* fRn(t1) .* fRn(s - t1) ./ sqrt(z .^ 2 - (2 * t1 - s) .^ 2) .* (1 - FRn(v * t - s)) * 1 / pi .* acos((z .^ 2 + (v * t - s) .^ 2 - x ^ 2) ./ (2 * z .* (v * t - s)));
        q2 = integral3(q2fun, (v * t - x) / 2, v * t, @(s) abs(x - (v * t - s)), @(s) min(s, x + (v * t - s)), @(s, z) (s - z) / 2, @(s, z) (s + z) / 2);
        nCDF(n) = q1 + q2;
    elseif ismember(n, nVec)
        sMax1 = x;
        sMax2 = (v * t + x) / 2;
        zMax1 = x;
        zMax2 = (v * t + x) / 2;
        tMax = 3 * MeanFlight;
        phiMax = 2 * pi;
        fun1 = 0;
        fun2 = 0;
        parfor k = 1 : MaxIter
            s1 = rand * sMax1 + v * t - x;
            s2 = rand * sMax2 + (v * t - x) / 2;
            z1 = rand * zMax1;
            z2 = rand * zMax2;
            t_i = rand(n - 2, 1) * tMax;
            theta_i = rand(n - 2, 1) * phiMax;
            W = sqrt(sum(t_i .* cos(theta_i)) ^ 2 + sum(t_i .* sin(theta_i)) ^ 2);
            tSum = sum(t_i);
            Con1 = (z1 ^ 2 - (s1 - tSum - W) ^ 2) * ((s1 - tSum + W) ^ 2 - z1 ^ 2);
            Con2 = (z2 ^ 2 - (s2 - tSum - W) ^ 2) * ((s2 - tSum + W) ^ 2 - z2 ^ 2);
            if (Con1 > 0) && (z1 < x - (v * t - s1))
                fun1 = fun1 + 4 * z1 / (2 * pi) ^ (n - 1) * fRn(s1 - tSum) * prod(fRn(t_i)) / sqrt(Con1) * (1 - FRn(v * t - s1));
            end
            if (Con2 > 0) && (z2 > abs(x - (v * t - s2))) && (z2 < min(s2, x + (v * t - s2)))
                fun2 = fun2 + 4 * z2 / (2 * pi) ^ (n - 1) * fRn(s2 - tSum) * prod(fRn(t_i)) / sqrt(Con2) * (1 - FRn(v * t - s2)) * 1 / pi .* acos((z2 ^ 2 + (v * t - s2) ^ 2 - x ^ 2) / (2 * z2 * (v * t - s2)));
            end
        end
        q1 = sMax1 * zMax1 * tMax ^ (n - 2) * phiMax ^ (n - 2) * fun1 / MaxIter;
        q2 = sMax2 * zMax2 * tMax ^ (n - 2) * phiMax ^ (n - 2) * fun2 / MaxIter;
        nCDF(n) = q1 + q2;
    else
        q1fun = @(s) FZ(x - (v * t - s)) .* (1 - FRn(v * t - s)) .* fS(s);
        q1 = integral(q1fun, v * t - x, v * t);
        q2fun = @(s, r) 1 / pi * acos((r .^ 2 + (v * t - s) .^ 2 - x ^ 2) ./ (2 * r .* (v * t - s))) .* fZ(r) .* (1 - FRn(v * t - s)) .* fS(s);
        q2 = integral2(q2fun, (v * t - x) / 2, v * t, @(s) abs(x - (v * t - s)), @(s) min(s, x + (v * t - s)));
        nCDF(n) = q1 + q2;
    end
end
A = sum(nCDF);