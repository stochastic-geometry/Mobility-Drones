function B = RWP_PDF_Exact(ux, t, u0, MaxN, v, sigmaRayleigh, muExpTime, MaxIter)
MeanFlight = sigmaRayleigh * sqrt(pi / 2);
nIntPDF = zeros(MaxN, 1);
fR1 = @(r1) raylpdf(r1, sigmaRayleigh);%@(r1) exppdf(r1, muExp);%
FR1 = @(r1) raylcdf(r1, sigmaRayleigh);%@(r1) expcdf(r1, muExp);%
fW1 = @(t) gampdf(t, 2, muExpTime);
FW1 = @(t) gamcdf(t, 2, muExpTime);
fW0 = @(t) exppdf(t, muExpTime);
FW0 = @(t) expcdf(t, muExpTime);
nIntPDF(1) = integral(@(x) fW0(t - x / v) .* (1 - FR1(x)) / v .* 1 / pi .* acos((x .^ 2 + ux ^ 2 - u0 ^ 2) ./ (2 * ux * x)), abs(ux - u0), min(v * t, ux + u0));
nIntPDF(2) = integral(@(x) fR1(x) .* (FW0(t - x / v) - FW1(t - x / v)) .* 1 / pi .* acos((x .^ 2 + ux ^ 2 - u0 ^ 2) ./ (2 * ux * x)), abs(ux - u0), min(v * t, ux + u0)) + ...
    integral3(@(x, w1, r1) 2 * x / pi .* (1 - FR1(v * t - v * w1 - r1)) .* fR1(r1) .* fW1(w1) ./ sqrt(((v * t - v * w1) .^ 2 - x .^ 2) .* (x .^ 2 - (2 * r1 - (v * t - v * w1)) .^ 2)) * 1 / pi .* acos((x .^ 2 + ux ^ 2 - u0 ^ 2) ./ (2 * ux * x)), ...
    abs(ux - u0), min(v * t, ux + u0), 0, @(x) t - x / v, @(x, w1) ((v * t - v * w1) - x) / 2, @(x, w1) ((v * t - v * w1) + x) / 2);
for n = 3 : MaxN
    fRn = @(rn) raylpdf(rn, sigmaRayleigh);%@(rn) exppdf(rn, muExp);%
    FRn = @(rn) raylcdf(rn, sigmaRayleigh);%@(rn) expcdf(rn, muExp);%
    fWn1 = @(tn) gampdf(tn, n, muExpTime);
    FWn1 = @(tn) gamcdf(tn, n, muExpTime);
    FWn2 = @(tn) gamcdf(tn, n - 1, muExpTime);
    xMax0 = min(v * t, ux + u0) - abs(ux - u0);
    sMax0 = v * t - abs(ux - u0);
    xMax1 = min(v * t, ux + u0) - abs(ux - u0);
    yMax1 = (v * t + min(v * t, ux + u0)) / 2;
    zMax1 = (v * t + min(v * t, ux + u0)) / 2;
    wMax1 = t;
    rMax = 3 * MeanFlight;
    thetaMax = 2 * pi;
    fun0 = 0;
    fun1 = 0;
    tic
    parfor k = 1 : MaxIter
        x0 = rand * xMax0 + abs(ux - u0);
        s0 = rand * sMax0 + abs(ux - u0);
        x1 = rand * xMax1 + abs(ux - u0);
        y1 = rand * yMax1 + (v * t - min(v * t, ux + u0)) / 2;
        z1 = rand * zMax1;
        w1 = rand * wMax1;
        r_i = rand(n - 2, 1) * rMax;
        theta_i = rand(n - 2, 1) * thetaMax;
        Kn = sqrt(sum(r_i .* cos(theta_i)) ^ 2 + sum(r_i .* sin(theta_i)) ^ 2);
        Jn = sum(r_i);
        Con0 = (x0 ^ 2 - (s0 - Jn - Kn) ^ 2) * ((s0 - Jn + Kn) ^ 2 - x0 ^ 2);
        Con1 = (z1 ^ 2 - ((y1 - v * w1) - Jn - Kn) ^ 2) * (((y1 - v * w1) - Jn + Kn) ^ 2 - z1 ^ 2);
        if (Con0 > 0) && (s0 > x0)
            fun0 = fun0 + 4 * x0 / (2 * pi) ^ (n - 1) * fRn(s0 - Jn) * prod(fRn(r_i)) / sqrt(Con0) * (FWn2(t - s0 / v) - FWn1(t - s0 / v)) * 1 / pi * acos((x0 ^ 2 + ux ^ 2 - u0 ^ 2) / (2 * ux * x0));
        end
        if (Con1 > 0) && (w1 < y1 / v) && (z1 > abs(x1 - (v * t - y1))) && (z1 < min(y1, x1 + (v * t - y1))) && (y1 > (v * t - x1) / 2)
            fun1 = fun1 + fWn1(w1) * 2 * x1 / pi * 4 * z1 / (2 * pi) ^ (n - 1) * fRn((y1 - v * w1) - Jn) * prod(fRn(r_i)) / sqrt(Con1) * (1 - FRn(v * t - y1)) / sqrt((x1 ^ 2 - (z1 - (v * t - y1)) ^ 2) * ((z1 + (v * t - y1)) ^ 2 - x1 ^ 2)) * 1 / pi * acos((x1 ^ 2 + ux ^ 2 - u0 ^ 2) / (2 * ux * x1));
        end
    end
    toc
    q0 = xMax0 * sMax0 * rMax ^ (n - 2) * thetaMax ^ (n - 2) * fun0 / MaxIter;
    q1 = xMax1 * yMax1 * zMax1 * wMax1 * rMax ^ (n - 2) * thetaMax ^ (n - 2) * fun1 / MaxIter;
    nIntPDF(n) = q0 + q1;
end
B = sum(nIntPDF);