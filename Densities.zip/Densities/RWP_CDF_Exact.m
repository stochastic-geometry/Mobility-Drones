function A = RWP_CDF_Exact(x, t, MaxN, v, sigmaRayleigh, muExpTime, aMat, MaxIter)
if x <= 0
    A = 0;
    return;
elseif x >= v * t
    A = 1;
    return;
end
MeanFlight = sigmaRayleigh * sqrt(pi / 2);
MeanN = v * t / MeanFlight;
nVec = max(floor(MeanN) - 2, 3) : max(ceil(MeanN) + 2, 3);
nCDF = zeros(MaxN, 1);
fR1 = @(r1) raylpdf(r1, sigmaRayleigh);%@(r1) exppdf(r1, muExp);%
FR1 = @(r1) raylcdf(r1, sigmaRayleigh);%@(r1) expcdf(r1, muExp);%
fW1 = @(t) gampdf(t, 2, muExpTime);
FW1 = @(t) gamcdf(t, 2, muExpTime);
fW0 = @(t) exppdf(t, muExpTime);
FW0 = @(t) expcdf(t, muExpTime);
nCDF(1) = integral(@(w1) fW0(w1) .* (1 - FR1(v * t - v * w1)), t - x / v, inf);
nCDF(2) = integral(@(r1) fR1(r1) .* (FW0(t - r1 / v) - FW1(t - r1 / v)), 0, x) + ...
    integral2(@(w1, r1) fR1(r1) .* fW1(w1) .* (1 - FR1(v * t - v * w1 - r1)), t - x / v, t, 0, @(w1) v * t - v * w1) + ...
    integral2(@(w1, r1) fR1(r1) .* fW1(w1) .* (1 - FR1(v * t - v * w1 - r1)) .* 1 / pi .* acos((r1 .^ 2 + (v * t - v * w1 - r1) .^ 2 - x ^ 2) ./ (2 * r1 .* (v * t - v * w1 - r1))), 0, t - x / v, @(w1) (v * t - v * w1 - x) / 2, @(w1) (v * t - v * w1 + x) / 2);
for n = 3 : MaxN
    m = n - 1;
    sigmaRayleighN = sqrt(m * sigmaRayleigh ^ 2);%sqrt((n - 1) / 2 * (sigma2Exp + muExp ^ 2));%
    fZ = @(r) raylpdf(r, sigmaRayleighN);
    FZ = @(r) raylcdf(r, sigmaRayleighN);
    fRn = @(rn) raylpdf(rn, sigmaRayleigh);%@(rn) exppdf(rn, muExp);%
    FRn = @(rn) raylcdf(rn, sigmaRayleigh);%@(rn) expcdf(rn, muExp);%
    fWn1 = @(tn) gampdf(tn, n, muExpTime);
    FWn1 = @(tn) gamcdf(tn, n, muExpTime);
    FWn2 = @(tn) gamcdf(tn, n - 1, muExpTime);
    if n == 3
        fS = @(s) s / (2 * sigmaRayleigh ^ 2) .* exp(-s .^ 2 / (2 * sigmaRayleigh ^ 2)) + sqrt(pi) / 4 * (s .^ 2 - 2 * sigmaRayleigh ^ 2) / (sigmaRayleigh ^ 3) .* exp(-s .^ 2 / (4 * sigmaRayleigh ^ 2)) .* erf(s / (2 * sigmaRayleigh));
    else
        b = sigmaRayleigh ^ 2 / (2 * m) * (factorial(2 * m) / factorial(m)) ^ (1 / m);
        a0 = aMat(m, 1);
        a1 = aMat(m, 2);
        a2 = aMat(m, 3);
        fS = @(s) (((s / sqrt(m)) .^ (2 * m - 1) .* exp(-(s / sqrt(m)) .^ 2 / (2 * b)) / (2 ^ (m - 1) * b ^ m * factorial(m - 1))) - (((s / sqrt(m)) - a2) .^ (2 * m - 2) .* exp(-a1 * ((s / sqrt(m)) - a2) .^ 2 / (2 * b)) / (2 ^ (m - 1) * b * (b / a1) ^ m * factorial(m - 1)) * a0 .* (b * (2 * m * (s / sqrt(m))  - a2) - a1 * (s / sqrt(m)) .* ((s / sqrt(m)) - a2) .^ 2))) / sqrt(m);
    end
    % fS = @(s) sqrt(n - 1) * (s / sqrt(n - 1)) .^ (2 * n - 3) .* exp(-(s / sqrt(n - 1)) .^ 2 / (2 * b)) / (2 ^ (n - 2) * b ^ (n - 1) * factorial(n - 2));
    % fS = @(s) gampdf(s, n - 1, muExpTime);
    if ismember(n, nVec)
        sMax0 = v * t;
        zMax0 = x;
        yMax1 = x;
        zMax1 = x;
        wMax1 = t;
        yMax2 = (v * t + x) / 2;
        zMax2 = (v * t + x) / 2;
        % if v * t < 3 * x
        %     zMax2 = v * t - x;
        % else
        %     zMax2 = 2 * x;
        % end
        wMax2 = t;
        rMax = 3 * MeanFlight;
        thetaMax = 2 * pi;
        fun0 = 0;
        fun1 = 0;
        fun2 = 0;
        parfor k = 1 : MaxIter
            s0 = rand * sMax0;
            z0 = rand * zMax0;
            y1 = rand * yMax1 + v * t - x;
            y2 = rand * yMax2 + (v * t - x) / 2;
            z1 = rand * zMax1;
            z2 = rand * zMax2;
            w1 = rand * wMax1;
            w2 = rand * wMax2;
            r_i = rand(n - 2, 1) * rMax;
            theta_i = rand(n - 2, 1) * thetaMax;
            Kn = sqrt(sum(r_i .* cos(theta_i)) ^ 2 + sum(r_i .* sin(theta_i)) ^ 2);
            Jn = sum(r_i);
            Con0 = (z0 ^ 2 - (s0 - Jn - Kn) ^ 2) * ((s0 - Jn + Kn) ^ 2 - z0 ^ 2);
            Con1 = (z1 ^ 2 - ((y1 - v * w1) - Jn - Kn) ^ 2) * (((y1 - v * w1) - Jn + Kn) ^ 2 - z1 ^ 2);
            Con2 = (z2 ^ 2 - ((y2 - v * w2) - Jn - Kn) ^ 2) * (((y2 - v * w2) - Jn + Kn) ^ 2 - z2 ^ 2);
            if (Con0 > 0) && (z0 < min(s0, x))
                fun0 = fun0 + 4 * z0 / (2 * pi) ^ (n - 1) * fRn(s0 - Jn) * prod(fRn(r_i)) / sqrt(Con0) * (FWn2(t - s0 / v) - FWn1(t - s0 / v));
            end
            if (Con1 > 0) && (w1 < y1 / v) && (z1 < x - (v * t - y1))
                fun1 = fun1 + fWn1(w1) * 4 * z1 / (2 * pi) ^ (n - 1) * fRn((y1 - v * w1) - Jn) * prod(fRn(r_i)) / sqrt(Con1) * (1 - FRn(v * t - y1));
            end
            if (Con2 > 0) && (w2 < y2 / v) && (z2 > abs(x - (v * t - y2))) && (z2 < min(y2, x + (v * t - y2)))
                fun2 = fun2 + fWn1(w2) * 4 * z2 / (2 * pi) ^ (n - 1) * fRn((y2 - v * w2) - Jn) * prod(fRn(r_i)) / sqrt(Con2) * (1 - FRn(v * t - y2)) * 1 / pi .* acos((z2 ^ 2 + (v * t - y2) ^ 2 - x ^ 2) / (2 * z2 * (v * t - y2)));
            end
        end
        q0 = sMax0 * zMax0 * rMax ^ (n - 2) * thetaMax ^ (n - 2) * fun0 / MaxIter;
        q1 = yMax1 * zMax1 * wMax1 * rMax ^ (n - 2) * thetaMax ^ (n - 2) * fun1 / MaxIter;
        q2 = yMax2 * zMax2 * wMax2 * rMax ^ (n - 2) * thetaMax ^ (n - 2) * fun2 / MaxIter;
        nCDF(n) = q0 + q1 + q2;
    else
        q0fun = @(s) fS(s) .* FZ(min(s, x)) .* (FWn2(t - s / v) - FWn1(t - s / v));
        q0 = integral(q0fun, 0, v * t);
        q1fun = @(y, w) fWn1(w) .* fS(y - v * w) .* FZ(x - (v * t - y)) .* (1 - FRn(v * t - y));
        q1 = integral2(q1fun, v * t - x, v * t, 0, @(y) y / v);
        q2fun = @(y, z, w) fWn1(w) .* fS(y - v * w) .* fZ(z) .* (1 - FRn(v * t - y)) .* 1 / pi .* acos((z .^ 2 + (v * t - y) .^ 2 - x ^ 2) ./ (2 * z .* (v * t - y)));
        q2 = integral3(q2fun, (v * t - x) / 2, v * t, @(y) abs(x - (v * t - y)), @(y) min(y, x + (v * t - y)), 0, @(y, z) y / v);
        nCDF(n) = q0 + q1 + q2;
    end
end
A = sum(nCDF);