%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%                                                                     %%%
%%%   Paper: Performance Characterization of Canonical Mobility Models  %%%
%%%          in Drone Cellular Networks                                 %%%
%%%   Authors: Morteza Banagar, Harpreet S. Dhillon                     %%%
%%%   Emails: mbanagar@vt.edu, hdhillon@vt.edu                          %%%
%%%                                                                     %%%
%%%   This code is used to generate the plot of Figs. 5 and 6,          %%%
%%%   density of the network of interferers in random walk and          %%%
%%%   random waypoint.                                                  %%%
%%%                                                                     %%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%% Load All Data
ClipData1 = 4000;
ClipData2 = ClipData1 / 10;
load('.\Data\Model1\Model1_ConstantMove_Density_Simulation.mat')
load('.\Data\Model1\Model1_ConstantMove_Density_Theory.mat')
Density_Simulation_Model1 = Density_Simulation(:, 1 : ClipData1);
Density_Theory_Model1 = Density_Theory(:, 1 : ClipData1);
load('.\Data\Model2\Model2_RandomStop_Density_Simulation.mat')
load('.\Data\Model2\Model2_RandomStop_Density_Theory.mat')
Density_Simulation_Model2 = Density_Simulation(:, 1 : ClipData1);
Density_Theory_Model2 = Density_Theory(:, 1 : ClipData1);
load('.\Data\Model3\Model3_RandomWalk_Density_Simulation.mat')
load('.\Data\Model3\Model3_RandomWalk_Density_Theory_Exact.mat')
load('.\Data\Model3\Model3_RandomWalk_Density_Theory_Approx.mat')
Density_Simulation_Model3 = Density_Simulation(:, 1 : ClipData1);
Density_Theory_Exact_Model3 = Density_Theory_Exact(:, 1 : ClipData2);
Density_Theory_Approx_Model3 = Density_Theory_Approx(:, 1 : ClipData2);
load('.\Data\Model4\Model4_RandomWayPoint_Density_Simulation.mat')
load('.\Data\Model4\Model4_RandomWayPoint_Density_Theory_Exact.mat')
load('.\Data\Model4\Model4_RandomWayPoint_Density_Theory_Approx.mat')
Density_Simulation_Model4 = Density_Simulation(:, 1 : ClipData1);
Density_Theory_Exact_Model4 = Density_Theory_Exact(:, 1 : ClipData2);
Density_Theory_Approx_Model4 = Density_Theory_Approx(:, 1 : ClipData2);
clear Density_Simulation Density_Theory Density_Theory_Exact Density_Theory_Approx
R_UAV = 1e4;
rVec1 = (1 : ClipData1).';
rVec2 = (10 : 10 : ClipData1).';
rVecDS = [100 : 200 : 1100, 1300 : 300 : 4000];
rVecDS2 = rVecDS / 10;
LineWidth = 2;
%% Plots
figure(1002)
s1 = subplot(121);
hold on
grid on
box on
plot(rVec1, Density_Theory_Model1(1, :), 'g', 'LineWidth', LineWidth, 'LineStyle', '-')
plot(rVec1, Density_Theory_Model1(2, :), 'm', 'LineWidth', LineWidth, 'LineStyle', ':')
plot(rVec1, Density_Theory_Model1(3, :), 'b', 'LineWidth', LineWidth, 'LineStyle', '-.')
plot(rVec1, Density_Theory_Model1(4, :), 'k', 'LineWidth', LineWidth, 'LineStyle', '--')
plot(rVecDS, Density_Simulation_Model1(:, rVecDS).', 'r', 'LineWidth', LineWidth, 'LineStyle', 'none', 'Marker', 'o', 'MarkerSize', 5, 'MarkerFaceColor', 'w')
title('SL', 'Interpreter', 'latex')
xlabel('$u_\mathbf{x}$ (m)', 'Interpreter', 'latex', 'FontSize', 12)
ylabel('$\lambda(t; u_\mathbf{x}, u_0)$', 'Interpreter', 'latex', 'FontSize', 12)
set(s1, 'FontName', 'Times', 'FontSize', 12)
legend('Theory: t = 20 s', 'Theory: t = 40 s', 'Theory: t = 50 s', 'Theory: t = 200 s', 'Simulation')
legend1 = legend(s1);
set(legend1, 'Location', 'southeast', 'FontSize', 12, 'Interpreter', 'latex')
ylim([0, 1.05e-6])
hold off
s2 = subplot(122);
hold on
grid on
box on
plot(rVec1, Density_Theory_Model2(1, :), 'g', 'LineWidth', LineWidth, 'LineStyle', '-')
plot(rVec1, Density_Theory_Model2(2, :), 'm', 'LineWidth', LineWidth, 'LineStyle', ':')
plot(rVec1, Density_Theory_Model2(3, :), 'b', 'LineWidth', LineWidth, 'LineStyle', '-.')
plot(rVec1, Density_Theory_Model2(4, :), 'k', 'LineWidth', LineWidth, 'LineStyle', '--')
plot(rVecDS, Density_Simulation_Model2(:, rVecDS).', 'r', 'LineWidth', LineWidth, 'LineStyle', 'none', 'Marker', 'o', 'MarkerSize', 5, 'MarkerFaceColor', 'w')
title('RS', 'Interpreter', 'latex')
xlabel('$u_\mathbf{x}$ (m)', 'Interpreter', 'latex', 'FontSize', 12)
ylabel('$\lambda(t; u_\mathbf{x}, u_0)$', 'Interpreter', 'latex', 'FontSize', 12)
set(s2, 'FontName', 'Times', 'FontSize', 12)
legend('Theory: t = 20 s', 'Theory: t = 40 s', 'Theory: t = 50 s', 'Theory: t = 200 s', 'Simulation')
legend2 = legend(s2);
set(legend2, 'Location', 'southeast', 'FontSize', 12, 'Interpreter', 'latex')
ylim([0, 1.05e-6])
hold off

figure(1003)
s3 = subplot(121);
hold on
grid on
box on
plot(rVec2, Density_Theory_Exact_Model3(1, :), 'b', 'LineWidth', LineWidth)
plot(rVecDS, Density_Simulation_Model3(1, rVecDS).', 'r', 'LineWidth', LineWidth, 'LineStyle', 'none', 'Marker', 'o', 'MarkerSize', 5, 'MarkerFaceColor', 'w')
plot(rVecDS, Density_Theory_Approx_Model3(1, rVecDS2).', 'g', 'LineWidth', LineWidth, 'LineStyle', 'none', 'Marker', 'x', 'MarkerSize', 7)
plot(rVec2, Density_Theory_Exact_Model3(2 : 4, :), 'b', 'LineWidth', LineWidth)
plot(rVecDS, Density_Simulation_Model3(2 : 4, rVecDS).', 'r', 'LineWidth', LineWidth, 'LineStyle', 'none', 'Marker', 'o', 'MarkerSize', 5, 'MarkerFaceColor', 'w')
plot(rVecDS, Density_Theory_Approx_Model3(2 : 4, rVecDS2).', 'g', 'LineWidth', LineWidth, 'LineStyle', 'none', 'Marker', 'x', 'MarkerSize', 7)
title('RW', 'Interpreter', 'latex')
xlabel('$u_\mathbf{x}$ (m)', 'Interpreter', 'latex', 'FontSize', 12)
ylabel('$\lambda(t; u_\mathbf{x}, u_0)$', 'Interpreter', 'latex', 'FontSize', 12)
set(s3, 'FontName', 'Times', 'FontSize', 12)
legend('Theory: Exact', 'Simulation', 'Theory: Approx.')
legend3 = legend(s3);
set(legend3, 'Location', 'southeast', 'FontSize', 12, 'Interpreter', 'latex')
ylim([0, 1.05e-6])
hold off
s4 = subplot(122);
hold on
grid on
box on
plot(rVec2, Density_Theory_Exact_Model4(1, :), 'b', 'LineWidth', LineWidth)
plot(rVecDS, Density_Simulation_Model4(1, rVecDS).', 'r', 'LineWidth', LineWidth, 'LineStyle', 'none', 'Marker', 'o', 'MarkerSize', 5, 'MarkerFaceColor', 'w')
plot(rVecDS, Density_Theory_Approx_Model4(1, rVecDS2).', 'g', 'LineWidth', LineWidth, 'LineStyle', 'none', 'Marker', 'x', 'MarkerSize', 7)
plot(rVec2, Density_Theory_Exact_Model4(2 : 3, :), 'b', 'LineWidth', LineWidth)
plot(rVec2, Density_Simulation_Model4(4, rVec2), 'b', 'LineWidth', LineWidth)
plot(rVecDS, Density_Simulation_Model4(2 : 4, rVecDS).', 'r', 'LineWidth', LineWidth, 'LineStyle', 'none', 'Marker', 'o', 'MarkerSize', 5, 'MarkerFaceColor', 'w')
plot(rVecDS, Density_Theory_Approx_Model4(2 : 4, rVecDS2).', 'g', 'LineWidth', LineWidth, 'LineStyle', 'none', 'Marker', 'x', 'MarkerSize', 7)
title('RWP', 'Interpreter', 'latex')
xlabel('$u_\mathbf{x}$ (m)', 'Interpreter', 'latex', 'FontSize', 12)
ylabel('$\lambda(t; u_\mathbf{x}, u_0)$', 'Interpreter', 'latex', 'FontSize', 12)
set(s4, 'FontName', 'Times', 'FontSize', 12)
legend('Theory: Exact', 'Simulation', 'Theory: Approx.')
legend4 = legend(s4);
set(legend4, 'Location', 'southeast', 'FontSize', 12, 'Interpreter', 'latex')
ylim([0, 1.05e-6])
hold off