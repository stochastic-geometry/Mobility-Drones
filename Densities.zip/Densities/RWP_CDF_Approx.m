function A = RWP_CDF_Approx(x, t, MaxN, v, sigmaRayleigh, muExpTime, aMat)
if x <= 0
    A = 0;
    return;
elseif x >= v * t
    A = 1;
    return;
end
nCDF = zeros(MaxN, 1);
fR1 = @(r1) raylpdf(r1, sigmaRayleigh);%@(r1) exppdf(r1, muExp);%
FR1 = @(r1) raylcdf(r1, sigmaRayleigh);%@(r1) expcdf(r1, muExp);%
fW1 = @(t) gampdf(t, 2, muExpTime);
FW1 = @(t) gamcdf(t, 2, muExpTime);
fW0 = @(t) exppdf(t, muExpTime);
FW0 = @(t) expcdf(t, muExpTime);
nCDF(1) = integral(@(w1) fW0(w1) .* (1 - FR1(v * t - v * w1)), t - x / v, inf);
nCDF(2) = integral(@(r1) fR1(r1) .* (FW0(t - r1 / v) - FW1(t - r1 / v)), 0, x) + ...
    integral2(@(w1, r1) fR1(r1) .* fW1(w1) .* (1 - FR1(v * t - v * w1 - r1)), t - x / v, t, 0, @(w1) v * t - v * w1) + ...
    integral2(@(w1, r1) fR1(r1) .* fW1(w1) .* (1 - FR1(v * t - v * w1 - r1)) .* 1 / pi .* acos((r1 .^ 2 + (v * t - v * w1 - r1) .^ 2 - x ^ 2) ./ (2 * r1 .* (v * t - v * w1 - r1))), 0, t - x / v, @(w1) (v * t - v * w1 - x) / 2, @(w1) (v * t - v * w1 + x) / 2);
for n = 3 : MaxN
    m = n - 1;
    sigmaRayleighN = sqrt(m * sigmaRayleigh ^ 2);%sqrt((n - 1) / 2 * (sigma2Exp + muExp ^ 2));%
    fZ = @(r) raylpdf(r, sigmaRayleighN);
    FZ = @(r) raylcdf(r, sigmaRayleighN);
    % fRn = @(rn) raylpdf(rn, sigmaRayleigh);%@(rn) exppdf(rn, muExp);%
    FRn = @(rn) raylcdf(rn, sigmaRayleigh);%@(rn) expcdf(rn, muExp);%
    fWn1 = @(tn) gampdf(tn, n, muExpTime);
    FWn1 = @(tn) gamcdf(tn, n, muExpTime);
    FWn2 = @(tn) gamcdf(tn, n - 1, muExpTime);
    if n == 3
        fS = @(s) s / (2 * sigmaRayleigh ^ 2) .* exp(-s .^ 2 / (2 * sigmaRayleigh ^ 2)) + sqrt(pi) / 4 * (s .^ 2 - 2 * sigmaRayleigh ^ 2) / (sigmaRayleigh ^ 3) .* exp(-s .^ 2 / (4 * sigmaRayleigh ^ 2)) .* erf(s / (2 * sigmaRayleigh));
    else
        b = sigmaRayleigh ^ 2 / (2 * m) * (factorial(2 * m) / factorial(m)) ^ (1 / m);
        a0 = aMat(m, 1);
        a1 = aMat(m, 2);
        a2 = aMat(m, 3);
        fS = @(s) (((s / sqrt(m)) .^ (2 * m - 1) .* exp(-(s / sqrt(m)) .^ 2 / (2 * b)) / (2 ^ (m - 1) * b ^ m * factorial(m - 1))) - (((s / sqrt(m)) - a2) .^ (2 * m - 2) .* exp(-a1 * ((s / sqrt(m)) - a2) .^ 2 / (2 * b)) / (2 ^ (m - 1) * b * (b / a1) ^ m * factorial(m - 1)) * a0 .* (b * (2 * m * (s / sqrt(m))  - a2) - a1 * (s / sqrt(m)) .* ((s / sqrt(m)) - a2) .^ 2))) / sqrt(m);
    end
    % fS = @(s) sqrt(n - 1) * (s / sqrt(n - 1)) .^ (2 * n - 3) .* exp(-(s / sqrt(n - 1)) .^ 2 / (2 * b)) / (2 ^ (n - 2) * b ^ (n - 1) * factorial(n - 2));
    % fS = @(s) gampdf(s, n - 1, muExp);
    q0fun = @(s) fS(s) .* FZ(min(s, x)) .* (FWn2(t - s / v) - FWn1(t - s / v));
    q0 = integral(q0fun, 0, v * t);
    q1fun = @(y, w) fWn1(w) .* fS(y - v * w) .* FZ(x - (v * t - y)) .* (1 - FRn(v * t - y));
    q1 = integral2(q1fun, v * t - x, v * t, 0, @(y) y / v);
    q2fun = @(y, z, w) fWn1(w) .* fS(y - v * w) .* fZ(z) .* (1 - FRn(v * t - y)) .* 1 / pi .* acos((z .^ 2 + (v * t - y) .^ 2 - x ^ 2) ./ (2 * z .* (v * t - y)));
    q2 = integral3(q2fun, (v * t - x) / 2, v * t, @(y) abs(x - (v * t - y)), @(y) min(y, x + (v * t - y)), 0, @(y, z) y / v);
    nCDF(n) = q0 + q1 + q2;
end
A = sum(nCDF);