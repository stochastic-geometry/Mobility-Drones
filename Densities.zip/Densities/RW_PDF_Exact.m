function B = RW_PDF_Exact(ux, t, u0, MaxN, v, sigmaRayleigh, MaxIter)
MeanFlight = sigmaRayleigh * sqrt(pi / 2);
nIntPDF = zeros(MaxN, 1);
fR1 = @(r1) raylpdf(r1, sigmaRayleigh);%@(r1) exppdf(r1, muExp);%
FR1 = @(r1) raylcdf(r1, sigmaRayleigh);%@(r1) expcdf(r1, muExp);%
if v * t < u0 + ux
    nIntPDF(1) = (1 - FR1(v * t)) * 1 / pi * acos(((v * t) ^ 2 + ux ^ 2 - u0 ^ 2) / (2 * ux * v * t));
else
    nIntPDF(1) = 0;
end
nIntPDF(2) = integral2(@(x, r1) 2 * x / pi .* (1 - FR1(v * t - r1)) .* fR1(r1) ./ sqrt((v ^ 2 * t ^ 2 - x .^ 2) .* (x .^ 2 - (v * t - 2 * r1) .^ 2)) * 1 / pi .* acos((x .^ 2 + ux ^ 2 - u0 ^ 2) ./ (2 * ux * x)), abs(ux - u0), min(v * t, ux + u0), @(x) (v * t - x) / 2, @(x) (v * t + x) / 2);
for n = 3 : MaxN
    fRn = @(rn) raylpdf(rn, sigmaRayleigh);%@(rn) exppdf(rn, muExp);%
    FRn = @(rn) raylcdf(rn, sigmaRayleigh);%@(rn) expcdf(rn, muExp);%
    xMax = min(v * t, ux + u0) - abs(ux - u0);
    sMax = (v * t + min(v * t, ux + u0)) / 2;
    zMax = (v * t + min(v * t, ux + u0)) / 2;%%%
    tMax = 3 * MeanFlight;
    phiMax = 2 * pi;
    fun2 = 0;
    parfor k = 1 : MaxIter
        x = rand * xMax + abs(ux - u0);
        s = rand * sMax + (v * t - min(v * t, ux + u0)) / 2;
        z = rand * zMax;%%%
        t_i = rand(n - 2, 1) * tMax;
        theta_i = rand(n - 2, 1) * phiMax;
        W = sqrt(sum(t_i .* cos(theta_i)) ^ 2 + sum(t_i .* sin(theta_i)) ^ 2);
        tSum = sum(t_i);
        Con = (z ^ 2 - (s - tSum - W) ^ 2) * ((s - tSum + W) ^ 2 - z ^ 2);
        if (s > (v * t - x) / 2) && (z > abs(x - (v * t - s))) && (z < min(s, x + (v * t - s))) && (Con > 0)
            fun2 = fun2 + 2 * x / pi * 4 * z / (2 * pi) ^ (n - 1) * fRn(s - tSum) * prod(fRn(t_i)) / sqrt(Con) * (1 - FRn(v * t - s)) / sqrt((x ^ 2 - (z - (v * t - s)) .^ 2) .* ((z + (v * t - s)) .^ 2 - x ^ 2)) * 1 / pi .* acos((x .^ 2 + ux ^ 2 - u0 ^ 2) ./ (2 * ux * x));
        end
    end
    q2 = xMax * sMax * zMax * tMax ^ (n - 2) * phiMax ^ (n - 2) * fun2 / MaxIter;
    nIntPDF(n) = q2;
end
B = sum(nIntPDF);