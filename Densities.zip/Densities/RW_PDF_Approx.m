function B = RW_PDF_Approx(ux, t, u0, MaxN, v, sigmaRayleigh, aMat, MaxIter)
% MeanFlight = sigmaRayleigh * sqrt(pi / 2);
nIntPDF = zeros(MaxN, 1);
fR1 = @(r1) raylpdf(r1, sigmaRayleigh);%@(r1) exppdf(r1, muExp);%
FR1 = @(r1) raylcdf(r1, sigmaRayleigh);%@(r1) expcdf(r1, muExp);%
if v * t < u0 + ux
    nIntPDF(1) = (1 - FR1(v * t)) * 1 / pi * acos(((v * t) ^ 2 + ux ^ 2 - u0 ^ 2) / (2 * ux * v * t));
else
    nIntPDF(1) = 0;
end
nIntPDF(2) = integral2(@(x, r1) 2 * x / pi .* (1 - FR1(v * t - r1)) .* fR1(r1) ./ sqrt((v ^ 2 * t ^ 2 - x .^ 2) .* (x .^ 2 - (v * t - 2 * r1) .^ 2)) * 1 / pi .* acos((x .^ 2 + ux ^ 2 - u0 ^ 2) ./ (2 * ux * x)), abs(ux - u0), min(v * t, ux + u0), @(x) (v * t - x) / 2, @(x) (v * t + x) / 2);
for n = 3 : MaxN
    tic
    m = n - 1;
    sigmaRayleighN = sqrt(m * sigmaRayleigh ^ 2);%sqrt((n - 1) / 2 * (sigma2Exp + muExp ^ 2));%
    fZ = @(r) raylpdf(r, sigmaRayleighN);
    % FZ = @(r) raylcdf(r, sigmaRayleighN);
    % fRn = @(rn) raylpdf(rn, sigmaRayleigh);%@(rn) exppdf(rn, muExp);%
    % FRn = @(rn) raylcdf(rn, sigmaRayleigh);%@(rn) expcdf(rn, muExp);%
    if n == 3
        fS = @(s) s / (2 * sigmaRayleigh ^ 2) .* exp(-s .^ 2 / (2 * sigmaRayleigh ^ 2)) + sqrt(pi) / 4 * (s .^ 2 - 2 * sigmaRayleigh ^ 2) / (sigmaRayleigh ^ 3) .* exp(-s .^ 2 / (4 * sigmaRayleigh ^ 2)) .* erf(s / (2 * sigmaRayleigh));
    else
        b = sigmaRayleigh ^ 2 / (2 * m) * (factorial(2 * m) / factorial(m)) ^ (1 / m);
        a0 = aMat(m, 1);
        a1 = aMat(m, 2);
        a2 = aMat(m, 3);
        fS = @(s) (((s / sqrt(m)) .^ (2 * m - 1) .* exp(-(s / sqrt(m)) .^ 2 / (2 * b)) / (2 ^ (m - 1) * b ^ m * factorial(m - 1))) - (((s / sqrt(m)) - a2) .^ (2 * m - 2) .* exp(-a1 * ((s / sqrt(m)) - a2) .^ 2 / (2 * b)) / (2 ^ (m - 1) * b * (b / a1) ^ m * factorial(m - 1)) * a0 .* (b * (2 * m * (s / sqrt(m))  - a2) - a1 * (s / sqrt(m)) .* ((s / sqrt(m)) - a2) .^ 2))) / sqrt(m);
    end
    % fS = @(s) sqrt(n - 1) * (s / sqrt(n - 1)) .^ (2 * n - 3) .* exp(-(s / sqrt(n - 1)) .^ 2 / (2 * b)) / (2 ^ (n - 2) * b ^ (n - 1) * factorial(n - 2));
    % fS = @(s) gampdf(s, n - 1, muExp);
    %{
    %{
    if n == 3
        xMax = min(v * t, ux + u0) - abs(ux - u0);
        sMax = (v * t + min(v * t, ux + u0)) / 2;
        zMax = (v * t + min(v * t, ux + u0)) / 2;
        tMax = 3 * MeanFlight;
        phiMax = 2 * pi;
        fun2 = 0;
        for k = 1 : MaxIter
            x = rand * xMax + abs(ux - u0);
            s = rand * sMax + (v * t - min(v * t, ux + u0)) / 2;
            z = rand * zMax;
            t_i = rand(n - 2, 1) * tMax;
            theta_i = rand(n - 2, 1) * phiMax;
            W = sqrt(sum(t_i .* cos(theta_i)) ^ 2 + sum(t_i .* sin(theta_i)) ^ 2);
            tSum = sum(t_i);
            Con = (z ^ 2 - (s - tSum - W) ^ 2) * ((s - tSum + W) ^ 2 - z ^ 2);
            if (s > (v * t - x) / 2) && (z > abs(x - (v * t - s))) && (z < min(s, x + (v * t - s))) && (Con > 0)
                fun2 = fun2 + 2 * x / pi * 4 * z / (2 * pi) ^ (n - 1) * fRn(s - tSum) * prod(fRn(t_i)) / sqrt(Con) * (1 - FRn(v * t - s)) / sqrt((x ^ 2 - (z - (v * t - s)) .^ 2) .* ((z + (v * t - s)) .^ 2 - x ^ 2)) * 1 / pi .* acos((x .^ 2 + ux ^ 2 - u0 ^ 2) ./ (2 * ux * x));
            end
        end
        q2 = xMax * sMax * zMax * tMax ^ (n - 2) * phiMax ^ (n - 2) * fun2 / MaxIter;
        nIntPDF(n) = q2;
    else
        xMax = min(v * t, ux + u0) - abs(ux - u0);
        sMax = (v * t + min(v * t, ux + u0)) / 2;
        zMax = (v * t + min(v * t, ux + u0)) / 2;
        fun2 = 0;
        for k = 1 : MaxIter
            x = rand * xMax + abs(ux - u0);
            s = rand * sMax + (v * t - min(v * t, ux + u0)) / 2;
            z = rand * zMax;
            if (s > (v * t - x) / 2) && (z > abs(x - (v * t - s))) && (z < min(s, x + (v * t - s)))
                fun2 = fun2 + 2 * x / pi * (1 - FR1(v * t - s)) .* fZ(z) .* fS(s) ./ sqrt(((z + (v * t - s)) .^ 2 - x .^ 2) .* (x .^ 2 - (z - (v * t - s)) .^ 2)) * 1 / pi .* acos((x .^ 2 + ux ^ 2 - u0 ^ 2) ./ (2 * ux * x));
            end
        end
        q2 = xMax * sMax * zMax * fun2 / MaxIter;
        nIntPDF(n) = q2;
    end
    %}
    %{
    q2fun = @(x, s, z) 2 * x / pi .* (1 - FR1(v * t - s)) .* fZ(z) .* fS(s) ./ sqrt(((z + (v * t - s)) .^ 2 - x .^ 2) .* (x .^ 2 - (z - (v * t - s)) .^ 2)) * 1 / pi .* acos((x .^ 2 + ux ^ 2 - u0 ^ 2) ./ (2 * ux * x));
    q2 = integral3(q2fun, abs(ux - u0), min(v * t, ux + u0), @(x) (v * t - x) / 2, v * t, @(x, s) abs(x - (v * t - s)), @(x, s) min(s, x + (v * t - s)));
    nIntPDF(n) = q2;
    %}
    %}
    %{}
    %{}
    xMax = min(v * t, ux + u0) - abs(ux - u0);
    sMax = (v * t + min(v * t, ux + u0)) / 2;
    zMax = (v * t + min(v * t, ux + u0)) / 2;
    fun2 = 0;
    parfor k = 1 : MaxIter
        x = rand * xMax + abs(ux - u0);
        s = rand * sMax + (v * t - min(v * t, ux + u0)) / 2;
        z = rand * zMax;
        if (s > (v * t - x) / 2) && (z > abs(x - (v * t - s))) && (z < min(s, x + (v * t - s)))
            fun2 = fun2 + 2 * x / pi * (1 - FR1(v * t - s)) .* fZ(z) .* fS(s) ./ sqrt(((z + (v * t - s)) .^ 2 - x .^ 2) .* (x .^ 2 - (z - (v * t - s)) .^ 2)) * 1 / pi .* acos((x .^ 2 + ux ^ 2 - u0 ^ 2) ./ (2 * ux * x));
        end
    end
    q2 = xMax * sMax * zMax * fun2 / MaxIter;
    nIntPDF(n) = q2;
    %}
    %{
    q2fun = @(x, s, z) 2 * x / pi .* (1 - FR1(v * t - s)) .* fZ(z) .* fS(s) ./ sqrt(((z + (v * t - s)) .^ 2 - x .^ 2) .* (x .^ 2 - (z - (v * t - s)) .^ 2)) * 1 / pi .* acos((x .^ 2 + ux ^ 2 - u0 ^ 2) ./ (2 * ux * x));
    q2 = integral3(q2fun, abs(ux - u0), min(v * t, ux + u0), @(x) (v * t - x) / 2, v * t, @(x, s) abs(x - (v * t - s)), @(x, s) min(s, x + (v * t - s)));
    nIntPDF(n) = q2;
    %}
    %}
    toc
end
B = sum(nIntPDF);