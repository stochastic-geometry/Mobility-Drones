%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%                                                                     %%%
%%%   Paper: Performance Characterization of Canonical Mobility Models  %%%
%%%          in Drone Cellular Networks                                 %%%
%%%   Authors: Morteza Banagar, Harpreet S. Dhillon                     %%%
%%%   Emails: mbanagar@vt.edu, hdhillon@vt.edu                          %%%
%%%                                                                     %%%
%%%   This code is used to generate the simulation data for Fig. 5,     %%%
%%%   density of the network of interferers in the random stop          %%%
%%%   mobility model                                                    %%%
%%%                                                                     %%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

datetime('now')
lambda0UAV = 1e-6;
R_UAV = 1e4;
NumUAV_Initial = lambda0UAV * pi * R_UAV ^ 2;
v = 45; % [km/h]
v = v / 3.6; % [m/s]
dr = 1;%10;%
NumR = round((R_UAV - dr) / dr) + 1;
sigmaRayleigh = 500 * sqrt(2 / pi);%muExp = 500;%
% c = 750;
u0 = 500;
tVec = [20, 40, 50, 200]; % Condition: v * t < R_UAV
tLen = length(tVec);
CountPointsAll = zeros(tLen, NumR);
Realizations = 1e8;
parfor i = 1 : Realizations
    CountPoints = zeros(tLen, NumR);
    NumUAV = poissrnd(NumUAV_Initial);
    PosUAV_Range = unifrnd(0, 1, NumUAV, 1);
    PosUAV_Range = R_UAV * sqrt(PosUAV_Range);
    PosUAV_Theta = unifrnd(0, 2 * pi, NumUAV, 1);
    f = PosUAV_Range <= u0;
    PosUAV_Range(f) = [];
    PosUAV_Theta(f) = [];
    NumUAV = length(PosUAV_Range);
    PosUAV = repmat(PosUAV_Range, 1, 2) .* [cos(PosUAV_Theta), sin(PosUAV_Theta)];
    DisplacedTheta = unifrnd(0, 2 * pi, NumUAV, 1);
    MovementVec = raylrnd(sigmaRayleigh, [NumUAV, 1]);%exprnd(muExp, [NumUAV, 1]);%c * ones(NumUAV, 1);%
    kk = 0;
    for t = tVec
        kk = kk + 1;
        d = min(v * t, MovementVec);
        vd = repmat(d, 1, 2) .* [cos(DisplacedTheta), sin(DisplacedTheta)];
        DisplacedPosUAV = PosUAV + vd;
        NewRange = sqrt(sum(DisplacedPosUAV .^ 2, 2));
        SlottedRange = ceil(NewRange / dr);
        [a, b] = hist(SlottedRange, unique(SlottedRange));
        CountPoints(kk, b) = a;
    end
    CountPoints = CountPoints(:, 1 : NumR);
    CountPointsAll = CountPointsAll + CountPoints;
end
AreaAnnulus = pi * (2 * (0 : dr : R_UAV - dr) * dr + dr ^ 2);
CountPointsAll = CountPointsAll / Realizations;
Density_Simulation = CountPointsAll ./ repmat(AreaAnnulus, tLen, 1);
save('Model2_RandomStop_Density_Simulation', 'Density_Simulation')
datetime('now')