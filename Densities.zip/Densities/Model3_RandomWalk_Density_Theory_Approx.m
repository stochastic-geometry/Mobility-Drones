%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%                                                                     %%%
%%%   Paper: Performance Characterization of Canonical Mobility Models  %%%
%%%          in Drone Cellular Networks                                 %%%
%%%   Authors: Morteza Banagar, Harpreet S. Dhillon                     %%%
%%%   Emails: mbanagar@vt.edu, hdhillon@vt.edu                          %%%
%%%                                                                     %%%
%%%   This code is used to generate the approximate theoretical data    %%%
%%%   for Fig. 6, density of the network of interferers in the          %%%
%%%   random walk mobility model                                        %%%
%%%                                                                     %%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

datetime('now')
lambda0UAV = 1e-6;
R_UAV = 1e4;
NumUAV_Initial = lambda0UAV * pi * R_UAV ^ 2;
v = 45; % [km/h]
v = v / 3.6; % [m/s]
dr = 10;%1;%
NumR = round((R_UAV - dr) / dr) + 1;
sigmaRayleigh = 500 * sqrt(2 / pi);%muExp = 500;%
u0 = 500;
tVec = [20, 40, 50, 200]; % Condition: v * t < R_UAV
tLen = length(tVec);
Density_Theory_Approx = zeros(tLen, NumR);
MaxIter = 1e7;
load('aMat.mat')
for T = 1 : tLen
    tic
    t = tVec(T);
    if t <= 50
        MaxN = 10;
    elseif t <= 100
        MaxN = 15;
    elseif t <= 300
        MaxN = 20;
    else
        MaxN = 30;
    end
    disp(['TimeTime: ', num2str(t)])
    rVec1 = dr : dr : round(abs(u0 - v * t));
    rLen1 = length(rVec1);
    if u0 < v * t
        for R = 1 : rLen1
            ux = rVec1(R);
            disp(R)
            disp('CDF1')
            A = RW_CDF_Approx(u0 - ux, t, MaxN, v, sigmaRayleigh, aMat);
            disp('PDF1')
            B = RW_PDF_Approx(ux, t, u0, MaxN, v, sigmaRayleigh, aMat, MaxIter);
            Density_Theory_Approx(T, R) = lambda0UAV * (1 - A - B);
        end
    end
    rVec2 = round(abs(u0 - v * t) + dr) : dr : round(u0 + v * t - dr);
    rLen2 = length(rVec2);
    for R = rLen1 + 1 : rLen1 + rLen2
        ux = rVec2(R - rLen1);
        if u0 - ux >= v * t
            A = 1;
            B = 0;
        elseif u0 - ux <= 0
            disp(R)
            A = 0;
            disp('PDF2')
            B = RW_PDF_Approx(ux, t, u0, MaxN, v, sigmaRayleigh, aMat, MaxIter);
        else
            disp(R)
            disp('CDF3')
            A = RW_CDF_Approx(u0 - ux, t, MaxN, v, sigmaRayleigh, aMat);
            disp('PDF3')
            B = RW_PDF_Approx(ux, t, u0, MaxN, v, sigmaRayleigh, aMat, MaxIter);
        end
        Density_Theory_Approx(T, R) = lambda0UAV * (1 - A - B);
    end
    rVec3 = round(u0 + v * t) : dr : round(R_UAV);
    rLen3 = length(rVec3);
    for R = rLen1 + rLen2 + 1 : rLen1 + rLen2 + rLen3
        % ux = rVec3(R - (rLen1 + rLen2));
        Density_Theory_Approx(T, R) = lambda0UAV;
    end
    toc
end
%{
Density_Theory_Approx = zeros(tLen, NumR);
% load('aMat.mat')
load('.\Data\aMat.mat')
for T = 1 : tLen
    tic
    t1 = tVec(T);
    if t1 <= 20
        MaxN = 10;
    elseif t1 <= 100
        MaxN = 15;
    elseif t1 <= 300
        MaxN = 20;
    else
        MaxN = 30;
    end
    disp(['TimeTime: ', num2str(t1)])
    rVec1 = dr : dr : round(min(u0, abs(u0 - v * t1)));
    rLen1 = length(rVec1);
    if u0 < v * t1
        for R = 1 : rLen1
            ux = rVec1(R);
            disp(R)
            x = u0 - ux;
            A = RW_CDF_Approx(x, t1, MaxN, v, sigmaRayleigh, aMat);
            B = RW_PDF_Approx(ux, t1, u0, MaxN, v, sigmaRayleigh, aMat, MaxIter);
            Density_Theory_Approx(T, R) = lambda0UAV * (1 - A - B);
        end
    end
    rVec2 = round(min(u0, abs(u0 - v * t1)) + dr) : dr : round(u0 + v * t1 - dr);
    rLen2 = length(rVec2);
    for R = rLen1 + 1 : rLen1 + rLen2
        ux = rVec2(R - rLen1);
        if u0 - ux >= v * t1
            A = 1;
            B = 0;
        elseif u0 - ux <= 0
            disp(R)
            A = 0;
            B = RW_PDF_Approx(ux, t1, u0, MaxN, v, sigmaRayleigh, aMat, MaxIter);
        else
            disp(R)
            x = u0 - ux;
            A = RW_CDF_Approx(x, t1, MaxN, v, sigmaRayleigh, aMat);
            B = RW_PDF_Approx(ux, t1, u0, MaxN, v, sigmaRayleigh, aMat, MaxIter);
        end
        Density_Theory_Approx(T, R) = lambda0UAV * (1 - A - B);
    end
    rVec3 = round(u0 + v * t1) : dr : round(R_UAV);
    rLen3 = length(rVec3);
    for R = rLen1 + rLen2 + 1 : rLen1 + rLen2 + rLen3
        % ux = rVec3(R - (rLen1 + rLen2));
        Density_Theory_Approx(T, R) = lambda0UAV;
    end
    toc
end
%}
save('Model3_RandomWalk_Density_Theory_Approx', 'Density_Theory_Approx')
datetime('now')