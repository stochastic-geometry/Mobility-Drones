%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%                                                                     %%%
%%%   Paper: Performance Characterization of Canonical Mobility Models  %%%
%%%          in Drone Cellular Networks                                 %%%
%%%   Authors: Morteza Banagar, Harpreet S. Dhillon                     %%%
%%%   Emails: mbanagar@vt.edu, hdhillon@vt.edu                          %%%
%%%                                                                     %%%
%%%   This code is used to generate the simulation data for Fig. 4,     %%%
%%%   distribution of L(t) in random waypoint.                          %%%
%%%                                                                     %%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

MaxN = 20;
v = 45; % [km/h]
v = v / 3.6; % [m/s]
t = 300;%100;%50;%
sigmaRayleigh = 500 * sqrt(2 / pi);%muExp = 500;%
muExpTime = 5;
Iter = 1e6;
Distances = raylrnd(sigmaRayleigh, [Iter, MaxN]);%exprnd(muExp, [Iter, MaxN]);%
Distances = [zeros(Iter, 1), Distances];
SumDist = cumsum(Distances, 2);
WaitTimes = exprnd(muExpTime, [Iter, MaxN + 1]);
W = cumsum(WaitTimes, 2);
M = [zeros(Iter, 1), SumDist(:, 2 : end) + v * W(:, 1 : end - 1)];
Y = SumDist + v * W;
IdentifierWait = (M <= v * t) & (Y > v * t);
IdentifierFlight = (Y(:, 1 : end - 1) <= v * t) & (M(:, 2 : end) > v * t);
IdentifierMixed = IdentifierFlight + IdentifierWait(:, 1 : end - 1);
IsMaxNEnough = round(nnz(any(IdentifierMixed, 2)) / Iter * 100);
Theta = [zeros(Iter, 1), unifrnd(0, 2 * pi, [Iter, MaxN])];
X = zeros(Iter, 1);
tic
for i = 1 : Iter
    fW = find(IdentifierWait(i, :) == 1);
    fF = find(IdentifierFlight(i, :) == 1);
    if ~isempty(fF)%fF == 3%
        A = Distances(i, 1 : fF) * cos(Theta(i, 1 : fF).');
        B = Distances(i, 1 : fF) * sin(Theta(i, 1 : fF).');
        Z = sqrt(A ^ 2 + B ^ 2);
        S = Y(i, fF);
        D = v * t - S;
        theta0 = atan2(B, A);
        phi0 = pi - Theta(i, fF + 1) + theta0;
        X(i) = sqrt(Z ^ 2 + D ^ 2 - 2 * Z * D * cos(phi0));
    elseif ~isempty(fW)%fW == 3%
        A = Distances(i, 1 : fW) * cos(Theta(i, 1 : fW).');
        B = Distances(i, 1 : fW) * sin(Theta(i, 1 : fW).');
        Z = sqrt(A ^ 2 + B ^ 2);
        X(i) = Z;
    else
        X(i) = v * t;
    end
end
toc
disp(['Confidence that number of flights is enough: ', num2str(IsMaxNEnough), '%'])

figure(103)
h = histogram(X, floor(v * t));
xData = h.BinEdges;
xData(end) = [];
yDataCDF = cumsum(h.BinCounts);
yDataCDF = yDataCDF / yDataCDF(end);
yDataPDF = h.BinCounts / (sum(h.BinCounts) * h.BinWidth);
plot(xData, yDataCDF)
title(['t = ', num2str(t), ' (s)'], 'interpreter', 'latex')
xlabel('Distance (m)', 'interpreter', 'latex')
ylabel('CDF', 'interpreter', 'latex')
figure(104)
plot(xData, yDataPDF)
title(['t = ', num2str(t), ' (s)'], 'interpreter', 'latex')
xlabel('Distance (m)', 'interpreter', 'latex')
ylabel('PDF', 'interpreter', 'latex')
save(['xVecSim', num2str(t)], 'xData')
save(['FinalCDFSim', num2str(t)], 'yDataCDF')
save(['FinalPDFSim', num2str(t)], 'yDataPDF')