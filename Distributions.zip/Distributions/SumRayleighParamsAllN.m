%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%                                                                     %%%
%%%   Paper: Performance Characterization of Canonical Mobility Models  %%%
%%%          in Drone Cellular Networks                                 %%%
%%%   Authors: Morteza Banagar, Harpreet S. Dhillon                     %%%
%%%   Emails: mbanagar@vt.edu, hdhillon@vt.edu                          %%%
%%%                                                                     %%%
%%%   This code is used to generate the coefficients needed for         %%%
%%%   derivation of the sum of N i.i.d. Rayleigh random variables.      %%%
%%%                                                                     %%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

MaxN = 40; % Do not exceed 44
NumPoints = 1e7;
sigmaRayleigh = 500 * sqrt(2 / pi);
aMat = zeros(MaxN, 3);
S = sum(raylrnd(sigmaRayleigh, 2, NumPoints), 1);
for n = 3 : MaxN
    disp(n)
    R_i = raylrnd(sigmaRayleigh, 1, NumPoints);
    S = S + R_i;
    b = sigmaRayleigh ^ 2 / (2 * n) * (factorial(2 * n) / factorial(n)) ^ (1 / n);
    h = histogram(S);
    xData = h.BinEdges;
    xData(end) = [];
    t = xData / sqrt(n);
    yData1 = cumsum(h.BinCounts);
    yData1 = yData1 / yData1(end);
    ApproxCDF = @(a, t) 1 - exp(-t .^ 2 / (2 * b)) .* sum((t .^ 2 / (2 * b)) .^ ((0 : n - 1).') ./ (factorial(0 : n - 1).')) - (t .* a(1) .* (t - a(3)) .^ (2 * n - 1) .* exp(-a(2) * (t - a(3)) .^ 2 / (2 * b)) / (2 ^ (n - 1) * (b / a(2)) ^ n * factorial(n - 1)));
    a0 = [0, 1, 0];
    FinalParams = lsqcurvefit(ApproxCDF, a0, t, yData1);
    aMat(n, :) = FinalParams;
end
%{
MaxN = 40; % Do not exceed 44
NumPoints = 1e7;
sigmaRayleigh = 500 * sqrt(2 / pi);
aMat = zeros(MaxN, 3);
S = cumsum(raylrnd(sigmaRayleigh, MaxN, NumPoints), 1);
for n = 3 : MaxN
    b = sigmaRayleigh ^ 2 / (2 * n) * (factorial(2 * n) / factorial(n)) ^ (1 / n);
    h = histogram(S(n, :));
    xData = h.BinEdges;
    xData(end) = [];
    t = xData / sqrt(n);
    yData1 = cumsum(h.BinCounts);
    yData1 = yData1 / yData1(end);
    ApproxCDF = @(a, t) 1 - exp(-t .^ 2 / (2 * b)) .* sum((t .^ 2 / (2 * b)) .^ ((0 : n - 1).') ./ (factorial(0 : n - 1).')) - (t .* a(1) .* (t - a(3)) .^ (2 * n - 1) .* exp(-a(2) * (t - a(3)) .^ 2 / (2 * b)) / (2 ^ (n - 1) * (b / a(2)) ^ n * factorial(n - 1)));
    a0 = [0, 1, 0];
    FinalParams = lsqcurvefit(ApproxCDF, a0, t, yData1);
    aMat(n, :) = FinalParams;
end
%}
save('aMat', 'aMat')