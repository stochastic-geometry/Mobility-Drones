%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%                                                                     %%%
%%%   Paper: Performance Characterization of Canonical Mobility Models  %%%
%%%          in Drone Cellular Networks                                 %%%
%%%   Authors: Morteza Banagar, Harpreet S. Dhillon                     %%%
%%%   Emails: mbanagar@vt.edu, hdhillon@vt.edu                          %%%
%%%                                                                     %%%
%%%   This code is used to generate the plot of Fig. 4, distribution    %%%
%%%   of L(t) in random walk and random waypoint.                       %%%
%%%                                                                     %%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%% Load Theoretical Data -- RW
load('.\Data\RW\t50\xVec50.mat')
load('.\Data\RW\t50\FinalPDF50.mat')
RW_xVec50_T = xVec;
RW_FinalPDF50_T = FinalPDF;
load('.\Data\RW\t100\xVec100.mat')
load('.\Data\RW\t100\FinalPDF100.mat')
RW_xVec100_T = xVec;
RW_FinalPDF100_T = FinalPDF;
load('.\Data\RW\t300\xVec300.mat')
load('.\Data\RW\t300\FinalPDF300.mat')
RW_xVec300_T = xVec;
RW_FinalPDF300_T = FinalPDF;
clear xVec FinalPDF
%% Load Simulation Data -- RW
load('.\Data\RW\t50\xVecSim50.mat')
load('.\Data\RW\t50\FinalPDFSim50.mat')
RW_xVec50_S = xData;
RW_FinalPDF50_S = yDataPDF;
load('.\Data\RW\t100\xVecSim100.mat')
load('.\Data\RW\t100\FinalPDFSim100.mat')
RW_xVec100_S = xData;
RW_FinalPDF100_S = yDataPDF;
load('.\Data\RW\t300\xVecSim300.mat')
load('.\Data\RW\t300\FinalPDFSim300.mat')
RW_xVec300_S = xData;
RW_FinalPDF300_S = yDataPDF;
clear xData yDataPDF
%% Load Theoretical Data -- RWP
load('.\Data\RWP\t50\xVec50.mat')
load('.\Data\RWP\t50\FinalPDF50.mat')
RWP_xVec50_T = xVec;
RWP_FinalPDF50_T = FinalPDF;
load('.\Data\RWP\t100\xVec100.mat')
load('.\Data\RWP\t100\FinalPDF100.mat')
RWP_xVec100_T = xVec;
RWP_FinalPDF100_T = FinalPDF;
load('.\Data\RWP\t300\xVec300.mat')
load('.\Data\RWP\t300\FinalPDF300.mat')
RWP_xVec300_T = xVec;
RWP_FinalPDF300_T = FinalPDF;
clear xVec FinalPDF
%% Load Simulation Data -- RWP
load('.\Data\RWP\t50\xVecSim50.mat')
load('.\Data\RWP\t50\FinalPDFSim50.mat')
RWP_xVec50_S = xData;
RWP_FinalPDF50_S = yDataPDF;
load('.\Data\RWP\t100\xVecSim100.mat')
load('.\Data\RWP\t100\FinalPDFSim100.mat')
RWP_xVec100_S = xData;
RWP_FinalPDF100_S = yDataPDF;
load('.\Data\RWP\t300\xVecSim300.mat')
load('.\Data\RWP\t300\FinalPDFSim300.mat')
RWP_xVec300_S = xData;
RWP_FinalPDF300_S = yDataPDF;
clear xData yDataPDF
%% Plots
RW_FinalPDF50_S_Interp = interp1(RW_xVec50_S, RW_FinalPDF50_S, RW_xVec50_T);
RWP_FinalPDF50_S_Interp = interp1(RWP_xVec50_S, RWP_FinalPDF50_S, RW_xVec50_T, 'linear', 'extrap');
RWP_FinalPDF50_T_Interp = interp1(RWP_xVec50_T, RWP_FinalPDF50_T, RW_xVec50_T, 'linear', 'extrap');
RW_FinalPDF100_S_Interp = interp1(RW_xVec100_S, RW_FinalPDF100_S, RW_xVec100_T);
RWP_FinalPDF100_S_Interp = interp1(RWP_xVec100_S, RWP_FinalPDF100_S, RW_xVec100_T, 'linear', 'extrap');
RWP_FinalPDF100_T_Interp = interp1(RWP_xVec100_T, RWP_FinalPDF100_T, RW_xVec100_T, 'linear', 'extrap');
RW_FinalPDF300_S_Interp = interp1(RW_xVec300_S, RW_FinalPDF300_S, RW_xVec300_T);
RWP_FinalPDF300_S_Interp = interp1(RWP_xVec300_S, RWP_FinalPDF300_S, RW_xVec300_T, 'linear', 'extrap');
RWP_FinalPDF300_T_Interp = interp1(RWP_xVec300_T, RWP_FinalPDF300_T, RW_xVec300_T, 'linear', 'extrap');
h = figure(1001);
s1 = subplot(131);
hold on
grid on
plot(RW_xVec50_T, RW_FinalPDF50_T, 'b', 'LineWidth', 2)
plot(RW_xVec50_T, RWP_FinalPDF50_T_Interp, 'k', 'LineWidth', 2, 'LineStyle', '--')
plot(RW_xVec50_T, RW_FinalPDF50_S_Interp, 'r', 'LineWidth', 2, 'LineStyle', 'none', 'Marker', 'o', 'MarkerSize', 6, 'MarkerFaceColor', 'w')
plot(RW_xVec50_T, RWP_FinalPDF50_S_Interp, 'r', 'LineWidth', 2, 'LineStyle', 'none', 'Marker', 'o', 'MarkerSize', 6, 'MarkerFaceColor', 'w')
title('$t = 50$ (s)', 'Interpreter', 'latex')
xlabel('Distance (m)', 'interpreter', 'latex')
% ylabel('PDF', 'interpreter', 'latex')
set(s1, 'FontName', 'Times', 'FontSize', 12)
legend('Theory: RW', 'Theory: RWP', 'Simulation')
legend1 = legend(s1);
set(legend1, 'Location', 'northwest', 'FontSize', 12, 'Interpreter', 'latex')
hold off
s2 = subplot(132);
hold on
grid on
plot(RW_xVec100_T, RW_FinalPDF100_T, 'b', 'LineWidth', 2)
plot(RW_xVec100_T, RWP_FinalPDF100_T_Interp, 'k', 'LineWidth', 2, 'LineStyle', '--')
plot(RW_xVec100_T, RW_FinalPDF100_S_Interp, 'r', 'LineWidth', 2, 'LineStyle', 'none', 'Marker', 'o', 'MarkerSize', 6, 'MarkerFaceColor', 'w')
plot(RW_xVec100_T, RWP_FinalPDF100_S_Interp, 'r', 'LineWidth', 2, 'LineStyle', 'none', 'Marker', 'o', 'MarkerSize', 6, 'MarkerFaceColor', 'w')
title('$t = 100$ (s)', 'Interpreter', 'latex')
xlabel('Distance (m)', 'interpreter', 'latex')
% ylabel('PDF', 'interpreter', 'latex')
set(s2, 'FontName', 'Times', 'FontSize', 12)
hold off
s3 = subplot(133);
hold on
grid on
plot(RW_xVec300_T, RW_FinalPDF300_T, 'b', 'LineWidth', 2)
plot(RW_xVec300_T, RWP_FinalPDF300_T_Interp, 'k', 'LineWidth', 2, 'LineStyle', '--')
plot(RW_xVec300_T, RW_FinalPDF300_S_Interp, 'r', 'LineWidth', 2, 'LineStyle', 'none', 'Marker', 'o', 'MarkerSize', 6, 'MarkerFaceColor', 'w')
plot(RW_xVec300_T, RWP_FinalPDF300_S_Interp, 'r', 'LineWidth', 2, 'LineStyle', 'none', 'Marker', 'o', 'MarkerSize', 6, 'MarkerFaceColor', 'w')
title('$t = 300$ (s)', 'Interpreter', 'latex')
xlabel('Distance (m)', 'interpreter', 'latex')
% ylabel('PDF', 'interpreter', 'latex')
set(s3, 'FontName', 'Times', 'FontSize', 12)
hold off

% savefig(h, 'Sim1_Distributions')
% saveas(h, 'Sim1_Distributions', 'epsc')