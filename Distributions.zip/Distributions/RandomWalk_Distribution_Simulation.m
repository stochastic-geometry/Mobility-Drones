%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%                                                                     %%%
%%%   Paper: Performance Characterization of Canonical Mobility Models  %%%
%%%          in Drone Cellular Networks                                 %%%
%%%   Authors: Morteza Banagar, Harpreet S. Dhillon                     %%%
%%%   Emails: mbanagar@vt.edu, hdhillon@vt.edu                          %%%
%%%                                                                     %%%
%%%   This code is used to generate the simulation data for Fig. 4,     %%%
%%%   distribution of L(t) in random walk.                              %%%
%%%                                                                     %%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

MaxN = 20;
v = 45; % [km/h]
v = v / 3.6; % [m/s]
t = 100;%600;%300;%
sigmaRayleigh = 500 * sqrt(2 / pi);%muExp = 500;%
Iter = 1e6; 
Distances = raylrnd(sigmaRayleigh, [Iter, MaxN]);%exprnd(muExp, [Iter, MaxN]);%
Distances = [zeros(Iter, 1), Distances];
SumDist = cumsum(Distances, 2);
Identifier = SumDist > v * t;
IsMaxNEnough = round(nnz(all(Identifier)) / MaxN * 100);
Theta = [zeros(Iter, 1), unifrnd(0, 2 * pi, [Iter, MaxN])];
X = zeros(Iter, 1);
tic
for i = 1 : Iter
    f = find(Identifier(i, :) == 1, 1, 'first');
    if ~isempty(f)
        A = Distances(i, 1 : f - 1) * cos(Theta(i, 1 : f - 1).');
        B = Distances(i, 1 : f - 1) * sin(Theta(i, 1 : f - 1).');
        Z = sqrt(A ^ 2 + B ^ 2);
        S = SumDist(i, f - 1);
        D = v * t - S;
        theta0 = atan2(A, B);
        phi0 = pi - Theta(i, f - 1) + theta0;
        X(i) = sqrt(Z ^ 2 + D ^ 2 - 2 * Z * D * cos(phi0));
    else
        X(i) = v * t;
    end
end
toc
disp(['Confidence that number of flights is enough: ', num2str(IsMaxNEnough), '%'])

figure(101)
h = histogram(X, floor(v * t));
xData = h.BinEdges;
xData(end) = [];
yDataCDF = cumsum(h.BinCounts);
yDataCDF = yDataCDF / yDataCDF(end);
yDataPDF = h.BinCounts / (sum(h.BinCounts) * h.BinWidth);
plot(xData, yDataCDF)
title(['t = ', num2str(t), ' (s)'], 'interpreter', 'latex')
xlabel('Distance (m)', 'interpreter', 'latex')
ylabel('CDF', 'interpreter', 'latex')
figure(102)
plot(xData, yDataPDF)
title(['t = ', num2str(t), ' (s)'], 'interpreter', 'latex')
xlabel('Distance (m)', 'interpreter', 'latex')
ylabel('PDF', 'interpreter', 'latex')
save(['xVecSim', num2str(t)], 'xData')
save(['FinalCDFSim', num2str(t)], 'yDataCDF')
save(['FinalPDFSim', num2str(t)], 'yDataPDF')