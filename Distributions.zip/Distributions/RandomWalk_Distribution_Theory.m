%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%                                                                     %%%
%%%   Paper: Performance Characterization of Canonical Mobility Models  %%%
%%%          in Drone Cellular Networks                                 %%%
%%%   Authors: Morteza Banagar, Harpreet S. Dhillon                     %%%
%%%   Emails: mbanagar@vt.edu, hdhillon@vt.edu                          %%%
%%%                                                                     %%%
%%%   This code is used to generate the theoretical data for Fig. 4,    %%%
%%%   distribution of L(t) in random walk.                              %%%
%%%                                                                     %%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

MaxN = 30;
v = 45; % [km/h]
v = v / 3.6; % [m/s]
t = 50;%100;%300;%
sigmaRayleigh = 500 * sqrt(2 / pi);%muExp = 500;%
% sigma2Exp = muExp ^ 2;
dx = 10;%50;%
MaxX = 1 * ceil(v * t / dx) * dx;
xVec = dx : dx : MaxX;
xLen = length(xVec);
disp(xLen)
MeanFlight = sigmaRayleigh * sqrt(pi / 2);
MeanN = v * t / MeanFlight;
nVec = max(floor(MeanN) - 2, 3) : max(ceil(MeanN) + 2, 3);
nCDF = zeros(round(MaxX / dx), MaxN);
nPDF = zeros(round(MaxX / dx), MaxN);
MaxIter = 1e6;
load('aMat.mat')
% tic
%%% n = 1 and n = 2
for X = 1 : xLen
    x = xVec(X);
    fR1 = @(r1) raylpdf(r1, sigmaRayleigh);%@(r1) exppdf(r1, muExp);%
    FR1 = @(r1) raylcdf(r1, sigmaRayleigh);%@(r1) expcdf(r1, muExp);%
    if x > v * t
        nCDF(X, 1) = 1 - FR1(v * t);
        nCDF(X, 2) = integral(@(r1) (1 - FR1(v * t - r1)) .* fR1(r1), 0, v * t);
        nPDF(X, 1) = 0;
        nPDF(X, 2) = 0;
    else
        nCDF(X, 1) = 0;
        nCDF(X, 2) = integral(@(r1) 1 / pi * (1 - FR1(v * t - r1)) .* fR1(r1) .* acos((r1 .^ 2 + (v * t - r1) .^ 2 - x ^ 2) ./ (2 * r1 .* (v * t - r1))), (v * t - x) / 2, (v * t + x) / 2);
        nPDF(X, 1) = 0;
        nPDF(X, 2) = integral(@(r1) 1 / pi * (1 - FR1(v * t - r1)) .* fR1(r1) .* 2 * x ./ sqrt((v ^ 2 * t ^ 2 - x ^ 2) .* (x ^ 2 - (v * t - 2 * r1) .^ 2)), (v * t - x) / 2, (v * t + x) / 2);
    end
end
%%% n >= 3
for X = 1 : xLen
    tic
    x = xVec(X);
    for n = 3 : MaxN
        m = n - 1;
        sigmaRayleighN = sqrt(m * sigmaRayleigh ^ 2);%sqrt((n - 1) / 2 * (sigma2Exp + muExp ^ 2));%
        fZ = @(r) raylpdf(r, sigmaRayleighN);
        FZ = @(r) raylcdf(r, sigmaRayleighN);
        fRn = @(rn) raylpdf(rn, sigmaRayleigh);%@(rn) exppdf(rn, muExp);%
        FRn = @(rn) raylcdf(rn, sigmaRayleigh);%@(rn) expcdf(rn, muExp);%
        if n == 3
            fS = @(s) s / (2 * sigmaRayleigh ^ 2) .* exp(-s .^ 2 / (2 * sigmaRayleigh ^ 2)) + sqrt(pi) / 4 * (s .^ 2 - 2 * sigmaRayleigh ^ 2) / (sigmaRayleigh ^ 3) .* exp(-s .^ 2 / (4 * sigmaRayleigh ^ 2)) .* erf(s / (2 * sigmaRayleigh));
        else
            b = sigmaRayleigh ^ 2 / (2 * m) * (factorial(2 * m) / factorial(m)) ^ (1 / m);
            a0 = aMat(m, 1);
            a1 = aMat(m, 2);
            a2 = aMat(m, 3);
            fS = @(s) (((s / sqrt(m)) .^ (2 * m - 1) .* exp(-(s / sqrt(m)) .^ 2 / (2 * b)) / (2 ^ (m - 1) * b ^ m * factorial(m - 1))) - (((s / sqrt(m)) - a2) .^ (2 * m - 2) .* exp(-a1 * ((s / sqrt(m)) - a2) .^ 2 / (2 * b)) / (2 ^ (m - 1) * b * (b / a1) ^ m * factorial(m - 1)) * a0 .* (b * (2 * m * (s / sqrt(m))  - a2) - a1 * (s / sqrt(m)) .* ((s / sqrt(m)) - a2) .^ 2))) / sqrt(m);
        end
        % fS = @(s) sqrt(n - 1) * (s / sqrt(n - 1)) .^ (2 * n - 3) .* exp(-(s / sqrt(n - 1)) .^ 2 / (2 * b)) / (2 ^ (n - 2) * b ^ (n - 1) * factorial(n - 2));
        % fS = @(s) gampdf(s, n - 1, muExp);
        if x > v * t
            nCDF(X, n) = integral(@(s) (1 - FRn(v * t - s)) .* fS(s), 0, v * t);
            nPDF(X, n) = 0;
        else
            if n == 3
                %% CDF Exact
                %{}
                q1fun = @(s, z, t1) (2 * z ./ (pi * sqrt(s .^ 2 - z .^ 2))) .* fRn(t1) .* fRn(s - t1) ./ sqrt(z .^ 2 - (2 * t1 - s) .^ 2) .* (1 - FRn(v * t - s));
                q1 = integral3(q1fun, v * t - x, v * t, 0, @(s) max(0, x - (v * t - s)), @(s, z) (s - z) / 2, @(s, z) (s + z) / 2);
                q2fun = @(s, z, t1) (2 * z ./ (pi * sqrt(s .^ 2 - z .^ 2))) .* fRn(t1) .* fRn(s - t1) ./ sqrt(z .^ 2 - (2 * t1 - s) .^ 2) .* (1 - FRn(v * t - s)) * 1 / pi .* acos((z .^ 2 + (v * t - s) .^ 2 - x ^ 2) ./ (2 * z .* (v * t - s)));
                q2 = integral3(q2fun, (v * t - x) / 2, v * t, @(s) abs(x - (v * t - s)), @(s) min(s, x + (v * t - s)), @(s, z) (s - z) / 2, @(s, z) (s + z) / 2);
                nCDF(X, n) = q1 + q2;
                %}
                %% PDF Exact
                %{}
                q2fun = @(s, z, t1) 2 * x / pi * (2 * z ./ (pi * sqrt(s .^ 2 - z .^ 2))) .* fRn(t1) .* fRn(s - t1) ./ sqrt(z .^ 2 - (2 * t1 - s) .^ 2) .* (1 - FRn(v * t - s)) ./ sqrt((x ^ 2 - (z - (v * t - s)) .^ 2) .* ((z + (v * t - s)) .^ 2 - x ^ 2));
                q2 = integral3(q2fun, (v * t - x) / 2, v * t, @(s) abs(x - (v * t - s)), @(s) min(s, x + (v * t - s)), @(s, z) (s - z) / 2, @(s, z) (s + z) / 2);
                nPDF(X, n) = q2;
                %}
            elseif ismember(n, nVec)
                %% CDF Exact
                %{}
                sMax = x;
                zMax = x;
                tMax = 3 * MeanFlight;
                phiMax = 2 * pi;
                fun1 = 0;
                parfor k = 1 : MaxIter
                    s = rand * sMax + v * t - x;
                    z = rand * zMax;
                    t_i = rand(n - 2, 1) * tMax;
                    theta_i = rand(n - 2, 1) * phiMax;
                    W = sqrt(sum(t_i .* cos(theta_i)) ^ 2 + sum(t_i .* sin(theta_i)) ^ 2);
                    tSum = sum(t_i);
                    Con = (z ^ 2 - (s - tSum - W) ^ 2) * ((s - tSum + W) ^ 2 - z ^ 2);
                    if (Con > 0) && (z < x - (v * t - s))
                        fun1 = fun1 + 4 * z / (2 * pi) ^ (n - 1) * fRn(s - tSum) * prod(fRn(t_i)) / sqrt(Con) * (1 - FRn(v * t - s));
                    end
                end
                q1 = sMax * zMax * tMax ^ (n - 2) * phiMax ^ (n - 2) * fun1 / MaxIter;
                sMax = (v * t + x) / 2;
                zMax = (v * t + x) / 2;
                tMax = 3 * MeanFlight;
                phiMax = 2 * pi;
                fun2 = 0;
                parfor k = 1 : MaxIter
                    s = rand * sMax + (v * t - x) / 2;
                    z = rand * zMax;
                    t_i = rand(n - 2, 1) * tMax;
                    theta_i = rand(n - 2, 1) * phiMax;
                    W = sqrt(sum(t_i .* cos(theta_i)) ^ 2 + sum(t_i .* sin(theta_i)) ^ 2);
                    tSum = sum(t_i);
                    Con = (z ^ 2 - (s - tSum - W) ^ 2) * ((s - tSum + W) ^ 2 - z ^ 2);
                    if (Con > 0) && (z > abs(x - (v * t - s))) && (z < min(s, x + (v * t - s)))
                        fun2 = fun2 + 4 * z / (2 * pi) ^ (n - 1) * fRn(s - tSum) * prod(fRn(t_i)) / sqrt(Con) * (1 - FRn(v * t - s)) * 1 / pi .* acos((z ^ 2 + (v * t - s) ^ 2 - x ^ 2) / (2 * z * (v * t - s)));
                    end
                end
                q2 = sMax * zMax * tMax ^ (n - 2) * phiMax ^ (n - 2) * fun2 / MaxIter;
                nCDF(X, n) = q1 + q2;
                %}
                %% PDF Exact
                %{}
                sMax = (v * t + x) / 2;
                zMax = (v * t + x) / 2;
                tMax = 3 * MeanFlight;
                phiMax = 2 * pi;
                fun2 = 0;
                parfor k = 1 : MaxIter
                    s = rand * sMax + (v * t - x) / 2;
                    z = rand * zMax;
                    t_i = rand(n - 2, 1) * tMax;
                    theta_i = rand(n - 2, 1) * phiMax;
                    W = sqrt(sum(t_i .* cos(theta_i)) ^ 2 + sum(t_i .* sin(theta_i)) ^ 2);
                    tSum = sum(t_i);
                    Con = (z ^ 2 - (s - tSum - W) ^ 2) * ((s - tSum + W) ^ 2 - z ^ 2);
                    if (Con > 0) && (z > abs(x - (v * t - s))) && (z < min(s, x + (v * t - s)))
                        fun2 = fun2 + 2 * x / pi * 4 * z / (2 * pi) ^ (n - 1) * fRn(s - tSum) * prod(fRn(t_i)) / sqrt(Con) * (1 - FRn(v * t - s)) / sqrt((x ^ 2 - (z - (v * t - s)) .^ 2) .* ((z + (v * t - s)) .^ 2 - x ^ 2));
                    end
                end
                q2 = sMax * zMax * tMax ^ (n - 2) * phiMax ^ (n - 2) * fun2 / MaxIter;
                nPDF(X, n) = q2;
                %}
            else
                %% CDF Approximation
                %{}
                q1fun = @(s) FZ(x - (v * t - s)) .* (1 - FRn(v * t - s)) .* fS(s);
                q1 = integral(q1fun, v * t - x, v * t);
                q2fun = @(s, r) 1 / pi * acos((r .^ 2 + (v * t - s) .^ 2 - x ^ 2) ./ (2 * r .* (v * t - s))) .* fZ(r) .* (1 - FRn(v * t - s)) .* fS(s);
                q2 = integral2(q2fun, (v * t - x) / 2, v * t, @(s) abs(x - (v * t - s)), @(s) min(s, x + (v * t - s)));
                nCDF(X, n) = q1 + q2;
                %}
                %% PDF Approximation
                %{}
                q2fun = @(s, r) 2 * x / pi ./ sqrt(((r + (v * t - s)) .^ 2 - x ^ 2) .* (x ^ 2 - (r - (v * t - s)) .^ 2)) .* fZ(r) .* (1 - FRn(v * t - s)) .* fS(s);
                q2 = integral2(q2fun, (v * t - x) / 2, v * t, @(s) abs(x - (v * t - s)), @(s) min(s, x + (v * t - s)));
                nPDF(X, n) = q2;
                %}
            end
        end
    end
    toc
end
FinalCDF = real(sum(nCDF, 2));
FinalPDF = real(sum(nPDF, 2));
FinalCDF(FinalCDF > 1) = 1;
% toc
figure(302)
subplot(211)
plot(xVec, FinalCDF, 'LineStyle', 'none', 'Marker', 'o')
title({'Rayleigh Distribution'; ['CDF and PDF @ t = ', num2str(t), ' (s)']}, 'interpreter', 'latex')
xlabel('Distance (m)', 'interpreter', 'latex')
subplot(212)
plot(xVec, FinalPDF, 'LineStyle', 'none', 'Marker', 'o')
xlabel('Distance (m)', 'interpreter', 'latex')
save(['nCDFt', num2str(t)], 'nCDF')
save(['nPDFt', num2str(t)], 'nPDF')