function q02 = RWP_ComputeQ02(u0, gam, h, alpha, v, t, sigmaRayleigh, muExpTime, MaxN, MaxIter)
MeanFlight = sigmaRayleigh * sqrt(pi / 2);
g1 = @(ux) ux ./ (1 + 1 / gam * ((ux .^ 2 + h ^ 2) / h ^ 2) .^ (alpha / 2));
nPDF = zeros(MaxN, 1);
fR1 = @(r1) raylpdf(r1, sigmaRayleigh);%@(r1) exppdf(r1, muExp);%
FR1 = @(r1) raylcdf(r1, sigmaRayleigh);%@(r1) expcdf(r1, muExp);%
fW1 = @(t) gampdf(t, 2, muExpTime);
FW1 = @(t) gamcdf(t, 2, muExpTime);
fW0 = @(t) exppdf(t, muExpTime);
FW0 = @(t) expcdf(t, muExpTime);
nPDF(1) = integral2(@(ux, x) g1(ux) .* fW0(t - x / v) .* (1 - FR1(x)) / v .* 1 / pi .* acos((x .^ 2 + ux .^ 2 - u0 ^ 2) ./ (2 * ux .* x)), 0, u0 + v * t, @(ux) abs(ux - u0), @(ux) min(v * t, ux + u0));
uxMax = u0 + v * t;
xMax = v * t;
wMax = t;
rMax = v * t;
fun = 0;
for k = 1 : MaxIter
    ux = rand * uxMax;
    x = rand * xMax;
    w = rand * wMax;
    r = rand * rMax;
    if (x > abs(ux - u0)) && (x < min(xMax, ux + u0)) && (w < t - x / v) && (r > (v * t - v * w - x) / 2) && (r < (v * t - v * w + x) / 2)
        fun = fun + g1(ux) * 2 * x / pi * (1 - FR1(v * t - v * w - r)) * fR1(r) * fW1(w) / sqrt(((v * t - v * w) ^ 2 - x ^ 2) * (x ^ 2 - (2 * r - (v * t - v * w)) ^ 2)) * 1 / pi * acos((x ^ 2 + ux ^ 2 - u0 ^ 2) / (2 * ux * x));
    end
end
qq = uxMax * xMax * wMax * rMax * fun / MaxIter;
nPDF(2) = qq + integral2(@(ux, x) g1(ux) .* fR1(x) .* (FW0(t - x / v) - FW1(t - x / v)) .* 1 / pi .* acos((x .^ 2 + ux .^ 2 - u0 ^ 2) ./ (2 * ux .* x)), 0, u0 + v * t, @(ux) abs(ux - u0), @(ux) min(v * t, ux + u0));
for n = 3 : MaxN
    fRn = @(rn) raylpdf(rn, sigmaRayleigh);%@(rn) exppdf(rn, muExp);%
    FRn = @(rn) raylcdf(rn, sigmaRayleigh);%@(rn) expcdf(rn, muExp);%
    fWn1 = @(tn) gampdf(tn, n, muExpTime);
    FWn1 = @(tn) gamcdf(tn, n, muExpTime);
    FWn2 = @(tn) gamcdf(tn, n - 1, muExpTime);
    uxMax = u0 + v * t;
    xMax0 = v * t;
    sMax0 = v * t;
    xMax1 = v * t;
    yMax1 = v * t;
    zMax1 = v * t;
    wMax1 = t;
    rMax = 3 * MeanFlight;
    thetaMax = 2 * pi;
    fun0 = 0;
    fun1 = 0;
    for k = 1 : MaxIter
        ux = rand * uxMax;
        x0 = rand * xMax0;
        s0 = rand * sMax0;
        x1 = rand * xMax1;
        y1 = rand * yMax1;
        z1 = rand * zMax1;
        w1 = rand * wMax1;
        r_i = rand(n - 2, 1) * rMax;
        theta_i = rand(n - 2, 1) * thetaMax;
        Kn = sqrt(sum(r_i .* cos(theta_i)) ^ 2 + sum(r_i .* sin(theta_i)) ^ 2);
        Jn = sum(r_i);
        Con0 = (x0 ^ 2 - (s0 - Jn - Kn) ^ 2) * ((s0 - Jn + Kn) ^ 2 - x0 ^ 2);
        Con1 = (z1 ^ 2 - ((y1 - v * w1) - Jn - Kn) ^ 2) * (((y1 - v * w1) - Jn + Kn) ^ 2 - z1 ^ 2);
        if (Con0 > 0) && (s0 > x0) && (x0 > abs(ux - u0)) && (x0 < min(xMax0, ux + u0)) 
            fun0 = fun0 + g1(ux) * 4 * x0 / (2 * pi) ^ (n - 1) * fRn(s0 - Jn) * prod(fRn(r_i)) / sqrt(Con0) * (FWn2(t - s0 / v) - FWn1(t - s0 / v)) * 1 / pi * acos((x0 ^ 2 + ux ^ 2 - u0 ^ 2) / (2 * ux * x0));
        end
        if (Con1 > 0) && (w1 < y1 / v) && (z1 > abs(x1 - (v * t - y1))) && (z1 < min(y1, x1 + (v * t - y1))) && (y1 > (v * t - x1) / 2) && (x1 > abs(ux - u0)) && (x1 < min(xMax1, ux + u0)) 
            fun1 = fun1 + g1(ux) * fWn1(w1) * 2 * x1 / pi * 4 * z1 / (2 * pi) ^ (n - 1) * fRn((y1 - v * w1) - Jn) * prod(fRn(r_i)) / sqrt(Con1) * (1 - FRn(v * t - y1)) / sqrt((x1 ^ 2 - (z1 - (v * t - y1)) ^ 2) * ((z1 + (v * t - y1)) ^ 2 - x1 ^ 2)) * 1 / pi * acos((x1 ^ 2 + ux ^ 2 - u0 ^ 2) / (2 * ux * x1));
        end
    end
    q0 = uxMax * xMax0 * sMax0 * rMax ^ (n - 2) * thetaMax ^ (n - 2) * fun0 / MaxIter;
    q1 = uxMax * xMax1 * yMax1 * zMax1 * wMax1 * rMax ^ (n - 2) * thetaMax ^ (n - 2) * fun1 / MaxIter;
    nPDF(n) = q0 + q1;
end
q02 = sum(nPDF);