function q02 = RW_ComputeQ02(u0, gam, h, alpha, v, t, sigmaRayleigh, MaxN, MaxIter)
MeanFlight = sigmaRayleigh * sqrt(pi / 2);
g1 = @(ux) ux ./ (1 + 1 / gam * ((ux .^ 2 + h ^ 2) / h ^ 2) .^ (alpha / 2));
nPDF = zeros(MaxN, 1);
fR1 = @(r1) raylpdf(r1, sigmaRayleigh);%@(r1) exppdf(r1, muExp);%
FR1 = @(r1) raylcdf(r1, sigmaRayleigh);%@(r1) expcdf(r1, muExp);%
nPDF(1) = (1 - FR1(v * t)) * integral(@(ux) g1(ux) .* 1 / pi .* acos(((v * t) ^ 2 + ux .^ 2 - u0 ^ 2) ./ (2 * ux * v * t)), v * t - u0, v * t + u0);
nPDF(2) = integral3(@(ux, x, r1) 2 * x / pi .* (1 - FR1(v * t - r1)) .* fR1(r1) ./ sqrt((v ^ 2 * t ^ 2 - x .^ 2) .* (x .^ 2 - (v * t - 2 * r1) .^ 2)) .* 1 / pi .* acos((x .^ 2 + ux .^ 2 - u0 ^ 2) ./ (2 * ux .* x)) .* g1(ux), 0, u0 + v * t, @(ux) abs(ux - u0), @(ux) min(v * t, ux + u0), @(ux, x) (v * t - x) / 2, @(ux, x) (v * t + x) / 2);
for n = 3 : MaxN
    fRn = @(rn) raylpdf(rn, sigmaRayleigh);%@(rn) exppdf(rn, muExp);%
    FRn = @(rn) raylcdf(rn, sigmaRayleigh);%@(rn) expcdf(rn, muExp);%
    uxMax = u0 + v * t;
    xMax = v * t;
    sMax = v * t;
    zMax = v * t;
    rMax = 3 * MeanFlight;
    thetaMax = 2 * pi;
    fun2 = 0;
    for k = 1 : MaxIter
        ux = rand * uxMax;
        x = rand * xMax;
        s = rand * sMax;
        z = rand * zMax;
        r_i = rand(n - 2, 1) * rMax;
        theta_i = rand(n - 2, 1) * thetaMax;
        Kn = sqrt(sum(r_i .* cos(theta_i)) ^ 2 + sum(r_i .* sin(theta_i)) ^ 2);
        Jn = sum(r_i);
        Con = (z ^ 2 - (s - Jn - Kn) ^ 2) * ((s - Jn + Kn) ^ 2 - z ^ 2);
        if (Con > 0) && (z > abs(x - (v * t - s))) && (z < min(s, x + (v * t - s))) && (s > (v * t - x) / 2) && (x > abs(ux - u0)) && (x < min(v * t, ux + u0))
            fun2 = fun2 + 2 * x / pi * 4 * z / (2 * pi) ^ (n - 1) * fRn(s - Jn) * prod(fRn(r_i)) / sqrt(Con) * (1 - FRn(v * t - s)) / sqrt((x ^ 2 - (z - (v * t - s)) ^ 2) * ((z + (v * t - s)) .^ 2 - x ^ 2)) * 1 / pi * acos((x ^ 2 + ux ^ 2 - u0 ^ 2) / (2 * ux * x)) * g1(ux);
        end
    end
    q2 = uxMax * xMax * sMax * zMax * rMax ^ (n - 2) * thetaMax ^ (n - 2) * fun2 / MaxIter;
    nPDF(n) = q2;
end
q02 = sum(nPDF);