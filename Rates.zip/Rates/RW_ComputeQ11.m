function q11 = RW_ComputeQ11(u0, gam, h, alpha, v, t, sigmaRayleigh, MaxN, MaxIter)
MeanFlight = sigmaRayleigh * sqrt(pi / 2);
g2 = @(ux) ux ./ (1 + 1 / gam * ((ux .^ 2 + h ^ 2) / ((u0 - v * t) ^ 2 + h ^ 2)) .^ (alpha / 2));
nCDF = zeros(MaxN, 1);
fR1 = @(r1) raylpdf(r1, sigmaRayleigh);%@(r1) exppdf(r1, muExp);%
FR1 = @(r1) raylcdf(r1, sigmaRayleigh);%@(r1) expcdf(r1, muExp);%
nCDF(1) = 0;
nCDF(2) = integral2(@(ux, r1) g2(ux) .* 1 / pi .* (1 - FR1(v * t - r1)) .* fR1(r1) .* acos((r1 .^ 2 + (v * t - r1) .^ 2 - (u0 - ux) .^ 2) ./ (2 * r1 .* (v * t - r1))), u0 - v * t, u0, @(ux) (v * t - (u0 - ux)) / 2, @(ux) (v * t + (u0 - ux)) / 2);
for n = 3 : MaxN
    fRn = @(rn) raylpdf(rn, sigmaRayleigh);%@(rn) exppdf(rn, muExp);%
    FRn = @(rn) raylcdf(rn, sigmaRayleigh);%@(rn) expcdf(rn, muExp);%
    uxMax = v * t;
    sMax1 = v * t;
    sMax2 = v * t;
    zMax1 = v * t;
    zMax2 = v * t;
    rMax = 3 * MeanFlight;
    thetaMax = 2 * pi;
    fun1 = 0;
    fun2 = 0;
    for k = 1 : MaxIter
        ux = rand * uxMax + u0 - v * t;
        s1 = rand * sMax1;
        s2 = rand * sMax2;
        z1 = rand * zMax1;
        z2 = rand * zMax2;
        r_i = rand(n - 2, 1) * rMax;
        theta_i = rand(n - 2, 1) * thetaMax;
        Kn = sqrt(sum(r_i .* cos(theta_i)) ^ 2 + sum(r_i .* sin(theta_i)) ^ 2);
        Jn = sum(r_i);
        Con1 = (z1 ^ 2 - (s1 - Jn - Kn) ^ 2) * ((s1 - Jn + Kn) ^ 2 - z1 ^ 2);
        Con2 = (z2 ^ 2 - (s2 - Jn - Kn) ^ 2) * ((s2 - Jn + Kn) ^ 2 - z2 ^ 2);
        if (Con1 > 0) && (z1 < (u0 - ux) - (v * t - s1)) && (s1 > v * t - (u0 - ux))
            fun1 = fun1 + 4 * z1 / (2 * pi) ^ (n - 1) * fRn(s1 - Jn) * prod(fRn(r_i)) / sqrt(Con1) * (1 - FRn(v * t - s1)) * g2(ux);
        end
        if (Con2 > 0) && (z2 > abs((u0 - ux) - (v * t - s2))) && (z2 < min(s2, (u0 - ux) + (v * t - s2))) && (s2 > (v * t - (u0 - ux)) / 2)
            fun2 = fun2 + 4 * z2 / (2 * pi) ^ (n - 1) * fRn(s2 - Jn) * prod(fRn(r_i)) / sqrt(Con2) * (1 - FRn(v * t - s2)) * g2(ux) * 1 / pi * acos((z2 ^ 2 + (v * t - s2) ^ 2 - (u0 - ux) ^ 2) / (2 * z2 * (v * t - s2)));
        end
    end
    q1 = uxMax * sMax1 * zMax1 * rMax ^ (n - 2) * thetaMax ^ (n - 2) * fun1 / MaxIter;
    q2 = uxMax * sMax2 * zMax2 * rMax ^ (n - 2) * thetaMax ^ (n - 2) * fun2 / MaxIter;
    nCDF(n) = q1 + q2;
end
q11 = sum(nCDF);