%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%                                                                     %%%
%%%   Paper: Performance Characterization of Canonical Mobility Models  %%%
%%%          in Drone Cellular Networks                                 %%%
%%%   Authors: Morteza Banagar, Harpreet S. Dhillon                     %%%
%%%   Emails: mbanagar@vt.edu, hdhillon@vt.edu                          %%%
%%%                                                                     %%%
%%%   This code is used to generate the theoretical data for Fig. 7,    %%%
%%%   average rate in the straight-line mobility model.                 %%%
%%%                                                                     %%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

datetime('now')
lambda0UAV = 1e-6;
v = 45; % [km/h]
v = v / 3.6; % [m/s]
tVec = [0.001, 10, 20, 30, 40 : 5 : 110, 120 : 10 : 160, 180 : 20 : 300].';
tLen = length(tVec);
alpha = 3;
h = 100;
m0 = 2;
m = 2;
Rate_Theory = zeros(tLen, 1);
tic
for it = 1 : tLen
    disp(it)
    t = tVec(it);
    g3 = @(gam, ux) (2 * pi * 2 * gam .* h ^ alpha .* ux .* (ux .^ 2 + h ^ 2) .^ (-alpha / 2)) ./ (1 + gam .* h ^ alpha .* (ux .^ 2 + h ^ 2) .^ (-alpha / 2)) .^ 3;
    g4 = @(gam, u0, ux) (2 * pi * 2 * gam .* ((u0 - v * t) .^ 2 + h ^ 2) .^ (alpha / 2) .* ux .* (ux .^ 2 + h ^ 2) .^ (-alpha / 2)) ./ (1 + gam .* (((u0 - v * t) .^ 2 + h ^ 2) ./ (ux .^ 2 + h ^ 2)) .^ (alpha / 2)) .^ 3;
    InnerInt1 = @(gam, u0) arrayfun(@(gam, u0) Fun1(u0, gam, h, alpha, v, t), gam, u0);
    InnerInt2 = @(gam, u0) arrayfun(@(gam, u0) Fun2(u0, gam, h, alpha, v, t), gam, u0);
    fun01 = @(gam, u0) exp(-2 * pi * lambda0UAV * InnerInt1(gam, u0)) .* raylpdf(u0, 1 / sqrt(2 * pi * lambda0UAV)) ./ (1 + gam);
    fun02 = @(gam, u0) exp(-2 * pi * lambda0UAV * InnerInt2(gam, u0)) .* raylpdf(u0, 1 / sqrt(2 * pi * lambda0UAV)) ./ (1 + gam);
    fun03 = @(gam, u0, ux) exp(-2 * pi * lambda0UAV * InnerInt1(gam, u0)) .* raylpdf(u0, 1 / sqrt(2 * pi * lambda0UAV)) ./ (1 + gam) .* lambda0UAV .* g3(gam, ux);
    fun04 = @(gam, u0, ux) exp(-2 * pi * lambda0UAV * InnerInt1(gam, u0)) .* raylpdf(u0, 1 / sqrt(2 * pi * lambda0UAV)) ./ (1 + gam) .* lambda0UAV .* g3(gam, ux) .* 1 / pi .* acos((u0 .^ 2 - ux .^ 2 - v ^ 2 * t ^ 2) ./ (2 * ux * v * t));
    fun05 = @(gam, u0, ux) exp(-2 * pi * lambda0UAV * InnerInt2(gam, u0)) .* raylpdf(u0, 1 / sqrt(2 * pi * lambda0UAV)) ./ (1 + gam) .* lambda0UAV .* g4(gam, u0, ux) .* 1 / pi .* acos((u0 .^ 2 - ux .^ 2 - v ^ 2 * t ^ 2) ./ (2 * ux * v * t));
    fun06 = @(gam, u0, ux) exp(-2 * pi * lambda0UAV * InnerInt2(gam, u0)) .* raylpdf(u0, 1 / sqrt(2 * pi * lambda0UAV)) ./ (1 + gam) .* lambda0UAV .* g4(gam, u0, ux);
    fun1 = @(gam, u0) arrayfun(@(gam, u0) fun01(gam, u0), gam, u0);
    fun2 = @(gam, u0) arrayfun(@(gam, u0) fun02(gam, u0), gam, u0);
    fun3 = @(gam, u0, ux) arrayfun(@(gam, u0, ux) fun03(gam, u0, ux), gam, u0, ux);
    fun4 = @(gam, u0, ux) arrayfun(@(gam, u0, ux) fun04(gam, u0, ux), gam, u0, ux);
    fun5 = @(gam, u0, ux) arrayfun(@(gam, u0, ux) fun05(gam, u0, ux), gam, u0, ux);
    fun6 = @(gam, u0, ux) arrayfun(@(gam, u0, ux) fun06(gam, u0, ux), gam, u0, ux);
    q1 = integral2(fun1, 0, inf, 0, v * t, 'method', 'iterated', 'AbsTol', 1e-4, 'RelTol', 1e-3);
    q2 = integral2(fun2, 0, inf, v * t, inf, 'method', 'iterated', 'AbsTol', 1e-4, 'RelTol', 1e-3);
    q3 = integral3(fun3, 0, inf, 0, v * t, 0, @(gam, u0) v * t - u0, 'method', 'iterated', 'AbsTol', 1e-4, 'RelTol', 1e-3);
    q4 = integral3(fun4, 0, inf, 0, v * t, @(gam, u0) v * t - u0, @(gam, u0) v * t + u0, 'method', 'iterated', 'AbsTol', 1e-4, 'RelTol', 1e-3);
    q5 = integral3(fun3, 0, inf, 0, v * t, @(gam, u0) v * t + u0, inf, 'method', 'iterated', 'AbsTol', 1e-4, 'RelTol', 1e-3);
    q6 = integral3(fun5, 0, inf, v * t, inf, @(gam, u0) u0 - v * t, @(gam, u0) u0 + v * t, 'method', 'iterated', 'AbsTol', 1e-4, 'RelTol', 1e-3);
    q7 = integral3(fun6, 0, inf, v * t, inf, @(gam, u0) u0 + v * t, inf, 'method', 'iterated', 'AbsTol', 1e-4, 'RelTol', 1e-3);
    Rate_Theory(it) = real(q1 + q2 + q3 + q4 + q5 + q6 + q7);
end
toc
save(['Rate_Theory_m0_', num2str(m0), '_m_', num2str(m)], 'Rate_Theory')
datetime('now')
function I = Fun1(u0, gam, h, alpha, v, t)
g1 = @(ux) ux .* (1 - (1 + gam .* h ^ alpha .* (ux .^ 2 + h ^ 2) .^ (-alpha / 2)) .^ (-2));
q01 = integral(g1, 0, v * t - u0, 'AbsTol', 1e-4, 'RelTol', 1e-3);
q02 = integral(@(ux) g1(ux) * 1 / pi .* acos((u0 ^ 2 - ux .^ 2 - v ^ 2 * t ^ 2) ./ (2 * ux * v * t)), v * t - u0, v * t + u0, 'AbsTol', 1e-4, 'RelTol', 1e-3);
q03 = integral(g1, v * t + u0, inf, 'method', 'iterated', 'AbsTol', 1e-4, 'RelTol', 1e-3);
I = q01 + q02 + q03;
end
function I = Fun2(u0, gam, h, alpha, v, t)
g2 = @(ux) ux .* (1 - (1 + gam .* (((u0 - v * t) .^ 2 + h ^ 2) ./ (ux .^ 2 + h ^ 2)) .^ (alpha / 2)) .^ (-2));
q02 = integral(@(ux) g2(ux) * 1 / pi .* acos((u0 ^ 2 - ux .^ 2 - v ^ 2 * t ^ 2) ./ (2 * ux * v * t)), u0 - v * t, u0 + v * t, 'AbsTol', 1e-4, 'RelTol', 1e-3);
q03 = integral(g2, u0 + v * t, inf, 'method', 'iterated', 'AbsTol', 1e-4, 'RelTol', 1e-3);
I = q02 + q03;
end