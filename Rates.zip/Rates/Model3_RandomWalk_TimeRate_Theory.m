%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%                                                                     %%%
%%%   Paper: Performance Characterization of Canonical Mobility Models  %%%
%%%          in Drone Cellular Networks                                 %%%
%%%   Authors: Morteza Banagar, Harpreet S. Dhillon                     %%%
%%%   Emails: mbanagar@vt.edu, hdhillon@vt.edu                          %%%
%%%                                                                     %%%
%%%   This code is used to generate the theoretical data for parts of   %%%
%%%   Figs. 9 and 10, average and session rates in the random walk      %%%
%%%   mobility model.                                                   %%%
%%%                                                                     %%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

datetime('now')
lambda0UAV = 1e-6;
v = 45; % [km/h]
v = v / 3.6; % [m/s]
h = 100;
alpha = 3;
P = 1;
P_Edge = 0.95;
SNR_Edge = 1;
d_Edge = sqrt(-log(1 - P_Edge) / (pi * lambda0UAV) + h ^ 2);
N0 = P * d_Edge ^ (-alpha) / SNR_Edge;
sigmaRayleigh = 500 * sqrt(2 / pi);%muExp = 500;%
tVec = [10 : 10 : 110, 120 : 20 : 200, 250, 300];
tLen = length(tVec);
MaxIter1 = 1e5;
MaxIter2 = 1e5;
MaxNVec = [2, 2, 2, 3, 3, 4, 4, 5, 5, 5, 6, 6, 7, 8, 9, 9, 10, 12]; % If you modify tVec, you have to modify MaxN as well
RateTime_Noiseless_Theory = zeros(1, tLen);
RateTime_Noisy_Theory = zeros(1, tLen);
StoreTime = zeros(1, tLen);
for it = 4 : tLen
    tic
    disp(['iT: ', num2str(it)])
    t = tVec(it);
    MaxN = MaxNVec(it);
    gMax = 500;
    u0Max = 1e4;%3e3; % Make sure v * tMax < u0Max
    u0Max1 = v * t;
    u0Max2 = u0Max - v * t;
    fun0 = 0;
    fun0N = 0;
    fun1 = 0;
    fun1N = 0;
    parfor k1 = 1 : MaxIter1
        gam = rand * gMax;
        u0 = rand * u0Max1;
        g1 = @(ux) ux ./ (1 + 1 / gam * ((ux .^ 2 + h ^ 2) / h ^ 2) .^ (alpha / 2));
        q00 = integral(g1, 0, inf);
        q01 = RW_ComputeQ01(u0, gam, h, alpha, v, t, sigmaRayleigh, MaxN, MaxIter2);
        q02 = RW_ComputeQ02(u0, gam, h, alpha, v, t, sigmaRayleigh, MaxN, MaxIter2);
        if q00 > q01 + q02 % Making sure MC integration does not produce funny results!
            Temp0 = exp(-2 * pi * lambda0UAV * (q00 - q01 - q02)) * raylpdf(u0, 1 / sqrt(2 * pi * lambda0UAV)) / (1 + gam);
            fun0 = fun0 + Temp0;
            fun0N = fun0N + Temp0 * exp(-gam * N0 * h ^ alpha / P);
        end
        u0 = rand * u0Max2 + v * t;
        g2 = @(ux) ux ./ (1 + 1 / gam * ((ux .^ 2 + h ^ 2) / ((u0 - v * t) ^ 2 + h ^ 2)) .^ (alpha / 2));
        q10 = integral(g2, u0 - v * t, inf);
        q11 = RW_ComputeQ11(u0, gam, h, alpha, v, t, sigmaRayleigh, MaxN, MaxIter2);
        q12 = RW_ComputeQ12(u0, gam, h, alpha, v, t, sigmaRayleigh, MaxN, MaxIter2);
        if q10 > q11 + q12 % Making sure MC integration does not produce funny results!
            Temp1 = exp(-2 * pi * lambda0UAV * (q10 - q11 - q12)) * raylpdf(u0, 1 / sqrt(2 * pi * lambda0UAV)) / (1 + gam);
            fun1 = fun1 + Temp1;
            fun1N = fun1N + Temp1 * exp(-gam * N0 * ((u0 - v * t) ^ 2 + h ^ 2) ^ (alpha / 2) / P);
        end
    end
    I0 = gMax * u0Max1 * fun0 / MaxIter1;
    I1 = gMax * u0Max2 * fun1 / MaxIter1;
    I0N = gMax * u0Max1 * fun0N / MaxIter1;
    I1N = gMax * u0Max2 * fun1N / MaxIter1;
    q01_Exact = real(I0 + I1);
    q01N_Exact = real(I0N + I1N);
    RateTime_Noiseless_Theory(it) = q01_Exact;
    RateTime_Noisy_Theory(it) = q01N_Exact;
    StoreTime(it) = toc;
    save(['Model3_RandomWalk_RateTime_Noiseless_Theory_', num2str(it)], 'RateTime_Noiseless_Theory')
    save(['Model3_RandomWalk_RateTime_Noisy_Theory_', num2str(it)], 'RateTime_Noisy_Theory')
    save('ElapsedTime_Rate', 'StoreTime')
    datetime('now')
end