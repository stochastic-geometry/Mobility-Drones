%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%                                                                     %%%
%%%   Paper: Performance Characterization of Canonical Mobility Models  %%%
%%%          in Drone Cellular Networks                                 %%%
%%%   Authors: Morteza Banagar, Harpreet S. Dhillon                     %%%
%%%   Emails: mbanagar@vt.edu, hdhillon@vt.edu                          %%%
%%%                                                                     %%%
%%%   This code is used to generate the theoretical data for parts of   %%%
%%%   Figs. 9 and 10, average and session rates in the random stop      %%%
%%%   mobility model.                                                   %%%
%%%                                                                     %%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

datetime('now')
lambda0UAV = 1e-6;
v = 45; % [km/h]
v = v / 3.6; % [m/s]
h = 100;
alpha = 3;
P = 1;
P_Edge = 0.95;
SNR_Edge = 1;
d_Edge = sqrt(-log(1 - P_Edge) / (pi * lambda0UAV) + h ^ 2);
N0 = P * d_Edge ^ (-alpha) / SNR_Edge;
sigmaRayleigh = 500 * sqrt(2 / pi);%muExp = 500;%
tMax = 300;
dt = 10;
tVec = [0.001, dt : dt : tMax];
tLen = length(tVec);
RateTime_Noiseless_Theory = zeros(tLen, 1);
RateTime_Noisy_Theory = zeros(tLen, 1);
parfor it = 1 : tLen
    tic
    t = tVec(it);
    InnerInt1 = @(gam, u0) arrayfun(@(gam, u0) Fun1(u0, gam, h, alpha, v, t, sigmaRayleigh), gam, u0);
    InnerInt2 = @(gam, u0) arrayfun(@(gam, u0) Fun2(u0, gam, h, alpha, v, t, sigmaRayleigh), gam, u0);
    fun01 = @(gam, u0) exp(-2 * pi * lambda0UAV * InnerInt1(gam, u0)) .* raylpdf(u0, 1 / sqrt(2 * pi * lambda0UAV)) ./ (1 + gam);
    fun02 = @(gam, u0) exp(-2 * pi * lambda0UAV * InnerInt2(gam, u0)) .* raylpdf(u0, 1 / sqrt(2 * pi * lambda0UAV)) ./ (1 + gam);
    fun03 = @(gam, u0) exp(-2 * pi * lambda0UAV * InnerInt1(gam, u0)) .* raylpdf(u0, 1 / sqrt(2 * pi * lambda0UAV)) .* exp(-gam * N0 / P * h ^ alpha) ./ (1 + gam);
    fun04 = @(gam, u0) exp(-2 * pi * lambda0UAV * InnerInt2(gam, u0)) .* raylpdf(u0, 1 / sqrt(2 * pi * lambda0UAV)) .* exp(-gam * N0 / P * ((u0 - v * t) .^ 2 + h ^ 2) ^ (alpha / 2)) ./ (1 + gam);
    fun1 = @(gam, u0) arrayfun(@(gam, u0) fun01(gam, u0), gam, u0);
    fun2 = @(gam, u0) arrayfun(@(gam, u0) fun02(gam, u0), gam, u0);
    fun3 = @(gam, u0) arrayfun(@(gam, u0) fun03(gam, u0), gam, u0);
    fun4 = @(gam, u0) arrayfun(@(gam, u0) fun04(gam, u0), gam, u0);
    q1 = integral2(fun1, 0, inf, 0, v * t);
    q2 = integral2(fun2, 0, inf, v * t, inf);
    q3 = integral2(fun3, 0, inf, 0, v * t);
    q4 = integral2(fun4, 0, inf, v * t, inf);
    q12_Exact = real(q1 + q2);
    q34_Exact = real(q3 + q4);
    RateTime_Noiseless_Theory(it) = q12_Exact;
    RateTime_Noisy_Theory(it) = q34_Exact;
    toc
end
save('Model2_RandomStop_RateTime_Noiseless_Theory', 'RateTime_Noiseless_Theory')
save('Model2_RandomStop_RateTime_Noisy_Theory', 'RateTime_Noisy_Theory')
% H1 = RateTime_Noiseless_Theory(1 : end - 1);
% H2 = RateTime_Noiseless_Theory(2 : end);
% H = (H1 + H2) * dt / 2;
% CumSumH = cumsum(H) ./ (dt * (1 : tLen - 1).');
% Rate_Theory = [RateTime_Noiseless_Theory(1); CumSumH];
% save('Model1_ConstantMove_Rate_Theory', 'Rate_Theory')
datetime('now')
function I = Fun1(u0, gam, h, alpha, v, t, sigmaRayleigh)
fL = @(r1) raylpdf(r1, sigmaRayleigh);%@(r1) exppdf(r1, muExp);%
FL = @(r1) raylcdf(r1, sigmaRayleigh);%@(r1) expcdf(r1, muExp);%
g1 = @(ux) ux ./ (1 + 1 / gam * ((ux .^ 2 + h ^ 2) / h ^ 2) .^ (alpha / 2));
beta1 = @(ux) (1 - FL(min(v * t, u0 + ux))) .* 1 / pi .* acos((u0 ^ 2 - ux .^ 2 - min(v * t, u0 + ux) .^ 2) ./ (2 * ux .* min(v * t, u0 + ux))) + FL(ux - u0);
beta2 = @(ux, l) fL(l) .* 1 / pi .* acos((u0 ^ 2 - ux .^ 2 - l .^ 2) ./ (2 .* ux .* l)) ;
q01 = integral(@(ux) g1(ux) .* beta1(ux), 0, v * t + u0);
q02 = integral2(@(ux, l) g1(ux) .* beta2(ux, l), 0, v * t + u0, @(ux) abs(ux - u0), @(ux) min(v * t, u0 + ux));
q03 = integral(g1, v * t + u0, inf);
I = q01 + q02 + q03;
end
function I = Fun2(u0, gam, h, alpha, v, t, sigmaRayleigh)
fL = @(r1) raylpdf(r1, sigmaRayleigh);%@(r1) exppdf(r1, muExp);%
FL = @(r1) raylcdf(r1, sigmaRayleigh);%@(r1) expcdf(r1, muExp);%
g2 = @(ux) ux ./ (1 + 1 / gam * ((ux .^ 2 + h ^ 2) / ((u0 - v * t) .^ 2 + h ^ 2)) .^ (alpha / 2));
beta1 = @(ux) (1 - FL(min(v * t, u0 + ux))) .* 1 / pi .* acos((u0 ^ 2 - ux .^ 2 - min(v * t, u0 + ux) .^ 2) ./ (2 * ux .* min(v * t, u0 + ux))) + FL(ux - u0);
beta2 = @(ux, l) fL(l) .* 1 / pi .* acos((u0 ^ 2 - ux .^ 2 - l .^ 2) ./ (2 .* ux .* l)) ;
q01 = integral(@(ux) g2(ux) .* beta1(ux), u0 - v * t, u0 + v * t);
q02 = integral2(@(ux, l) g2(ux) .* beta2(ux, l), u0 - v * t, u0 + v * t, @(ux) abs(ux - u0), v * t);
q03 = integral(g2, v * t + u0, inf);
I = q01 + q02 + q03;
end