function q01 = RWP_ComputeQ01(u0, gam, h, alpha, v, t, sigmaRayleigh, muExpTime, MaxN, MaxIter)
MeanFlight = sigmaRayleigh * sqrt(pi / 2);
g1 = @(ux) ux ./ (1 + 1 / gam * ((ux .^ 2 + h ^ 2) / h ^ 2) .^ (alpha / 2));
nCDF = zeros(MaxN, 1);
fR1 = @(r1) raylpdf(r1, sigmaRayleigh);%@(r1) exppdf(r1, muExp);%
FR1 = @(r1) raylcdf(r1, sigmaRayleigh);%@(r1) expcdf(r1, muExp);%
fW1 = @(t) gampdf(t, 2, muExpTime);
FW1 = @(t) gamcdf(t, 2, muExpTime);
fW0 = @(t) exppdf(t, muExpTime);
FW0 = @(t) expcdf(t, muExpTime);
nCDF(1) = integral2(@(ux, w1) g1(ux) .* fW0(w1) .* (1 - FR1(v * t - v * w1)), 0, u0, @(ux) t - (u0 - ux) / v, inf);
nCDF(2) = integral2(@(ux, r1) g1(ux) .* fR1(r1) .* (FW0(t - r1 / v) - FW1(t - r1 / v)), 0, u0, 0, @(ux) u0 - ux) + ...
    integral3(@(ux, w1, r1) g1(ux) .* fR1(r1) .* fW1(w1) .* (1 - FR1(v * t - v * w1 - r1)), 0, u0, @(ux) t - (u0 - ux) / v, t, 0, @(ux, w1) v * t - v * w1) + ...
    integral3(@(ux, w1, r1) g1(ux) .* fR1(r1) .* fW1(w1) .* (1 - FR1(v * t - v * w1 - r1)) .* 1 / pi .* acos((r1 .^ 2 + (v * t - v * w1 - r1) .^ 2 - (u0 - ux) .^ 2) ./ (2 * r1 .* (v * t - v * w1 - r1))), 0, u0, 0, @(ux) t - (u0 - ux) / v, @(ux, w1) (v * t - v * w1 - (u0 - ux)) / 2, @(ux, w1) (v * t - v * w1 + (u0 - ux)) / 2);
for n = 3 : MaxN
    fRn = @(rn) raylpdf(rn, sigmaRayleigh);%@(rn) exppdf(rn, muExp);%
    FRn = @(rn) raylcdf(rn, sigmaRayleigh);%@(rn) expcdf(rn, muExp);%
    fWn1 = @(tn) gampdf(tn, n, muExpTime);
    FWn1 = @(tn) gamcdf(tn, n, muExpTime);
    FWn2 = @(tn) gamcdf(tn, n - 1, muExpTime);
    uxMax = u0;
    sMax0 = v * t;
    zMax0 = u0;
    yMax1 = u0;
    zMax1 = u0;
    wMax1 = t;
    yMax2 = (v * t + u0) / 2;
    zMax2 = (v * t + u0) / 2;
    wMax2 = t;
    rMax = 3 * MeanFlight;
    thetaMax = 2 * pi;
    fun0 = 0;
    fun1 = 0;
    fun2 = 0;
    for k = 1 : MaxIter
        ux = rand * uxMax;
        s0 = rand * sMax0;
        z0 = rand * zMax0;
        y1 = rand * yMax1 + v * t - u0;
        y2 = rand * yMax2 + (v * t - u0) / 2;
        z1 = rand * zMax1;
        z2 = rand * zMax2;
        w1 = rand * wMax1;
        w2 = rand * wMax2;
        r_i = rand(n - 2, 1) * rMax;
        theta_i = rand(n - 2, 1) * thetaMax;
        Kn = sqrt(sum(r_i .* cos(theta_i)) ^ 2 + sum(r_i .* sin(theta_i)) ^ 2);
        Jn = sum(r_i);
        Con0 = (z0 ^ 2 - (s0 - Jn - Kn) ^ 2) * ((s0 - Jn + Kn) ^ 2 - z0 ^ 2);
        Con1 = (z1 ^ 2 - ((y1 - v * w1) - Jn - Kn) ^ 2) * (((y1 - v * w1) - Jn + Kn) ^ 2 - z1 ^ 2);
        Con2 = (z2 ^ 2 - ((y2 - v * w2) - Jn - Kn) ^ 2) * (((y2 - v * w2) - Jn + Kn) ^ 2 - z2 ^ 2);
        if (Con0 > 0) && (z0 < min(s0, u0 - ux))
            fun0 = fun0 + 4 * z0 / (2 * pi) ^ (n - 1) * fRn(s0 - Jn) * prod(fRn(r_i)) / sqrt(Con0) * (FWn2(t - s0 / v) - FWn1(t - s0 / v)) * g1(ux);
        end
        if (Con1 > 0) && (w1 < y1 / v) && (z1 < (u0 - ux) - (v * t - y1)) && (y1 > v * t - (u0 - ux))
            fun1 = fun1 + fWn1(w1) * 4 * z1 / (2 * pi) ^ (n - 1) * fRn((y1 - v * w1) - Jn) * prod(fRn(r_i)) / sqrt(Con1) * (1 - FRn(v * t - y1)) * g1(ux);
        end
        if (Con2 > 0) && (w2 < y2 / v) && (z2 > abs((u0 - ux) - (v * t - y2))) && (z2 < min(y2, (u0 - ux) + (v * t - y2))) && (y2 > (v * t - (u0 - ux)) / 2)
            fun2 = fun2 + fWn1(w2) * 4 * z2 / (2 * pi) ^ (n - 1) * fRn((y2 - v * w2) - Jn) * prod(fRn(r_i)) / sqrt(Con2) * (1 - FRn(v * t - y2)) * g1(ux) * 1 / pi * acos((z2 ^ 2 + (v * t - y2) ^ 2 - (u0 - ux) ^ 2) / (2 * z2 * (v * t - y2)));
        end
    end
    q0 = uxMax * sMax0 * zMax0 * rMax ^ (n - 2) * thetaMax ^ (n - 2) * fun0 / MaxIter;
    q1 = uxMax * yMax1 * zMax1 * wMax1 * rMax ^ (n - 2) * thetaMax ^ (n - 2) * fun1 / MaxIter;
    q2 = uxMax * yMax2 * zMax2 * wMax2 * rMax ^ (n - 2) * thetaMax ^ (n - 2) * fun2 / MaxIter;
    nCDF(n) = q0 + q1 + q2;
end
q01 = sum(nCDF);