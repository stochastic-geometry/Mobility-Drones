These codes generate Fig. 7-10 of [1].
You can run the code for each mobility model to generate the data for each figure. Note that because of the Monte-Carlo integration, running Models 3 and 4 (random walk and random waypoint, respectively) takes longer time than others.

Please cite [1] if you reuse any part of these codes.

[1] M. Banagar and H. S. Dhillon, “Performance characterization of canonical mobility models in drone cellular networks”, available online: https://arxiv.org/abs/1908.05243