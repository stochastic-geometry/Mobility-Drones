%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%                                                                     %%%
%%%   Paper: Performance Characterization of Canonical Mobility Models  %%%
%%%          in Drone Cellular Networks                                 %%%
%%%   Authors: Morteza Banagar, Harpreet S. Dhillon                     %%%
%%%   Emails: mbanagar@vt.edu, hdhillon@vt.edu                          %%%
%%%                                                                     %%%
%%%   This code is used to generate the simulation data for parts of    %%%
%%%   Figs. 9 and 10, average and session rates in the random waypoint  %%%
%%%   mobility model.                                                   %%%
%%%                                                                     %%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

datetime('now')
lambda0UAV = 1e-6;
R_UAV = 1e5;
NumUAV_Initial = lambda0UAV * pi * R_UAV ^ 2;
v = 45; % [km/h]
v = v / 3.6; % [m/s]
alpha = 3;
h = 100;
P = 1;
P_Edge = 0.95;
SNR_Edge = 1;
d_Edge = sqrt(-log(1 - P_Edge) / (pi * lambda0UAV) + h ^ 2);
N0 = P * d_Edge ^ (-alpha) / SNR_Edge;
sigmaRayleigh = 500 * sqrt(2 / pi);%muExp = 500;%
muExpTime = 5;
dt = 1;%10;
tMax = 300;%600;
tVec = dt : dt : tMax;
tLen = length(tVec);
dg = 1;
gamMax = 400;
gVec = 0 : dg : gamMax;
gLen = length(gVec);
Realizations = 1e6;
MaxN = 20;
ProbCoverTime_Noiseless_Simulation = zeros(tLen + 1, gLen);
ProbCoverTime_Noisy_Simulation = zeros(tLen + 1, gLen);
SINR_Noiseless = zeros(Realizations, tLen + 1);
SINR_Noisy = zeros(Realizations, tLen + 1);
tic
parfor i = 1 : Realizations
    NumUAV = poissrnd(NumUAV_Initial);
    PosUAV_Range = unifrnd(0, 1, NumUAV, 1);
    PosUAV_Range = R_UAV * sqrt(PosUAV_Range);
    PosUAV_Theta = unifrnd(0, 2 * pi, NumUAV, 1);
    PosUAV = repmat(PosUAV_Range, 1, 2) .* [cos(PosUAV_Theta), sin(PosUAV_Theta)];
    [~, u0Ind] = min(PosUAV_Range);
    Interferers = setdiff(1 : NumUAV, u0Ind);
    RecoverTheta = pi + PosUAV_Theta(u0Ind);
    Temp_Noiseless = zeros(1, tLen + 1);
    Temp_Noisy = zeros(1, tLen + 1);
    DisplacedPosUAV = PosUAV;
    PosUAV3D = [DisplacedPosUAV, h * ones(NumUAV, 1)];
    DistanceUAV2UE = sqrt(sum(PosUAV3D .^ 2, 2));
    FadingUAV2UE = exprnd(1, NumUAV, tLen + 1);
    TotalPower = sum(P * FadingUAV2UE(:, 1) .* (DistanceUAV2UE .^ (-alpha)));
    ReceivedPower = P * FadingUAV2UE(u0Ind, 1) * (DistanceUAV2UE(u0Ind) ^ (-alpha));
    Interference = TotalPower - ReceivedPower;
    Temp_Noiseless(1) = ReceivedPower / Interference;
    Temp_Noisy(1) = ReceivedPower / (N0 + Interference);
    MovementDistVec = raylrnd(sigmaRayleigh, [NumUAV, MaxN]);%exprnd(mu, [NumUAV, MaxN]);%
    MovementThetaVec = unifrnd(0, 2 * pi, [NumUAV, MaxN]);
    MovementThetaVec(u0Ind, :) = RecoverTheta;
    WaitTimeVec = exprnd(muExpTime, [NumUAV, MaxN + 1]);
    S = [zeros(NumUAV, 1), cumsum(MovementDistVec, 2)];
    W = cumsum(WaitTimeVec, 2);
    M = [zeros(NumUAV, 1), S(:, 2 : end) + v * W(:, 1 : end - 1)];
    Y = S + v * W;
    RC = [zeros(NumUAV, 1), cumsum(MovementDistVec .* cos(MovementThetaVec), 2)];
    RS = [zeros(NumUAV, 1), cumsum(MovementDistVec .* sin(MovementThetaVec), 2)];
    it = 1;
    for t = tVec
        it = it + 1;
        for j = Interferers
            for n = 1 : MaxN
                M1 = M(j, n);
                M2 = M(j, n + 1);
                Y1 = Y(j, n);
                if (v * t >= M1) && (v * t < Y1) % Waiting Period
                    DisplacedPosUAV(j, :) = [PosUAV(j, 1) + RC(j, n), PosUAV(j, 2) + RS(j, n)];
                    break;
                elseif (v * t >= Y1) && (v * t < M2) % Flight Period
                    vd = (v * t - Y1) * [cos(MovementThetaVec(j, n)), sin(MovementThetaVec(j, n))];
                    DisplacedPosUAV(j, :) = [PosUAV(j, 1) + RC(j, n) + vd(1), PosUAV(j, 2) + RS(j, n) + vd(2)];
                    break;
                end
            end
        end
        if norm(DisplacedPosUAV(u0Ind, :)) >= v * dt
            DisplacedPosUAV(u0Ind, :) = PosUAV(u0Ind, :) + v * t * [cos(RecoverTheta), sin(RecoverTheta)];
        else
            DisplacedPosUAV(u0Ind, :) = [0, 0];
        end
        PosUAV3D = [DisplacedPosUAV, h * ones(NumUAV, 1)];
        DistanceUAV2UE = sqrt(sum(PosUAV3D .^ 2, 2));
        % FadingUAV2UE = exprnd(1, NumUAV, 1);
        TotalPower = P * FadingUAV2UE(:, it).' * (DistanceUAV2UE .^ (-alpha));
        ReceivedPower = P * FadingUAV2UE(u0Ind, it) * (DistanceUAV2UE(u0Ind) ^ (-alpha));
        Interference = TotalPower - ReceivedPower;
        Temp_Noiseless(it) = ReceivedPower / Interference;
        Temp_Noisy(it) = ReceivedPower / (N0 + Interference);
    end
    SINR_Noiseless(i, :) = Temp_Noiseless;
    SINR_Noisy(i, :) = Temp_Noisy;
end
toc
parfor it = 1 : tLen + 1
    for ig = 1 : gLen
        gam = ig - 1;%gVec(ig);
        ProbCoverTime_Noiseless_Simulation(it, ig) = nnz(SINR_Noiseless(:, it) >= gam) / Realizations;
        ProbCoverTime_Noisy_Simulation(it, ig) = nnz(SINR_Noisy(:, it) >= gam) / Realizations;
    end
end
RateTime_Noiseless_Simulation = mean(log(1 + SINR_Noiseless)).';
RateTime_Noisy_Simulation = mean(log(1 + SINR_Noisy)).';
save('Model4_RandomWayPoint_ProbCoverTime_Noiseless_Simulation', 'ProbCoverTime_Noiseless_Simulation')
save('Model4_RandomWayPoint_ProbCoverTime_Noisy_Simulation', 'ProbCoverTime_Noisy_Simulation')
save('Model4_RandomWayPoint_RateTime_Noiseless_Simulation', 'RateTime_Noiseless_Simulation')
save('Model4_RandomWayPoint_RateTime_Noisy_Simulation', 'RateTime_Noisy_Simulation')
datetime('now')